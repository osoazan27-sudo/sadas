# MuseGen 前置选项页（TikTok pre-lander）

参考：`survey.cloneai.ai/cloneai-star-in-the-music-video`（Pixery Labs 漏斗，47 屏）。
我们的版本：**5 道选择题 → 1.4 秒回显 → 结果页（可复制的 Description + 3 步操作 + 如实预期）→ 跳 musegen.ai**。
纯静态（HTML/CSS/JS，无构建、无框架），整个 `site/` 约 150 KB（含 5 个自托管字体，首屏实际下载 <400 KB 有测试断言）。

## 怎么看 / 怎么测

```
preview.cmd                       # 本机预览 http://127.0.0.1:8620/?utm_source=tiktok&ttclid=TEST123
node tools\serve.js site 8620 0.0.0.0   # 想用同一 Wi-Fi 的手机看：开 0.0.0.0，再访问 http://<本机IP>:8620/
test.cmd                          # 124 项验收（无头 Chrome、临时 profile、不出本机；任何指向线上站的请求都会被拦下并记录）
node tools\shoot.js http://127.0.0.1:8620 shots\x 390 844   # 逐屏截图
node tools\art_sheet.js shots\art.png                       # 8 张场景图在 9:16 / 16:9 预览框里的裁切
```

## 流程

| 步 | 问题 | 选项（全部来自产品真实选项） | 对应产品里的位置 |
|---|---|---|---|
| 1 | Where should your music video take place? | Paris dusk · Rainy Night in Tokyo · Arena Rock · Cliff Piano · Road Trip in Camper Van · Sunset grassland · Street Rap · Village Under Starry Sky | MV 页 **Style template** 列表里的真名 |
| 2 | What does your song sound like? | Pop & Vocals · Hip-Hop & Rap · EDM & Electronic · Lo-Fi & Chill Beats · Jazz & Soul · Classical & Orchestral · Cinematic & Soundtracks · Not sure yet | AI Song Maker 的 7 个曲风组 |
| 3 | Who's the star of the video? | Me（传一张正脸照）/ Let AI cast the lead（不用照片） | **Image to Video** / **Music to Video** 两个标签 |
| 4 | Where's your song? | 有文件 / 在 Suno / 先试官方曲目 | Upload music / Suno songs / Choose music → Official music |
| 5 | Where will you post it? | Vertical 9:16 / Widescreen 16:9 | Ratio |

结果页按答案生成：一段 ≤1000 字符的 Description（可复制，对应站内 Description 框上限）、按答案定制的 3 步「点哪里」、"What to expect"（登录 / 脚本 10–15 分钟 / 免费预览 / 失败退积分）、粘性 CTA。

**出口**：`https://www.musegen.ai/mv-generation/rb00_1music` + 原 URL 的 query **逐字节原样**（utm_*、ttclid…）+ 5 个 `pl_*` 追加参数。
实测（2026-11-13）：`rb00_1music` 是促销码捕获路径——写 `mg_ttclid`、`mg_promo_code`、`mg_mv_first_landing` 等 cookie，再 307 到 `/mv-generation?<完整 query>`，追加参数也原样保留；但站点的 `mg_mv_first_landing` **只记** utm_source/medium/campaign 与 ttclid，所以 `pl_*` 不会污染站内归因，也不会被站内记录（GA 等工具能从 URL 读到）。不想要就把 `config.js` 的 `appendPicks` 设为 `false`。

## 配置（`site/assets/config.js`）

| 项 | 默认 | 说明 |
|---|---|---|
| `destination` | `…/mv-generation/rb00_1music` | 必须保留 slug，否则不写 ttclid/促销码 cookie |
| `songMakerUrl` | `…/ai-song-maker` | 仅"先试官方曲目"这一支显示一个安静的次级链接 |
| `forwardQuery` | `true` | 原 query 原样转发 |
| `appendPicks` | `true` | 追加 `pl=quiz&pl_scene=…&pl_genre=…&pl_star=…&pl_song=…&pl_fmt=…` |
| `tiktokPixel` | `''`（关） | 填像素 code 即开；发自定义事件 `PL_Start / PL_Pick / PL_Result / PL_Copy / PL_Cta / PL_SongMaker`，不碰 ViewContent 等标准事件，不会污染现有像素的优化信号。默认像素 Ai music-Test 的 code 是 `DBHGIPBC77U8K2BMJ8NG` |
| `ga4` | `''`（关） | 同上 |

两个统计都关着时：**页面零第三方请求、零数据外发**（测试里断言过）。事件只含 step/value，不含任何个人数据。

## 文案事实对照表（页面上每句产品相关的话从哪来；核对日期 2026-11-13）

| 页面说法 | 依据 | 把握 |
|---|---|---|
| 8 个场景名 | MV 页 Style template 面板前 20 项（游客态 UI 实测） | 实测（**模板库是动态的**，站点改了要回查） |
| 7 个曲风 | AI Song Maker genre1–7（站点 i18n） | 原文 |
| "Add one clear, front-facing photo — your character stays consistent across shots" | MV 页 Upload photo 说明原文 | 原文 |
| "Let AI cast the lead — No photo needed" | Music to Video 标签表单没有照片项（实测）+ 脚本结果里有 "AI-designed lead" 标签 | **推断** → 建议你用 Music to Video 真点一次确认 |
| MP3 / WAV / M4A | MV 页 meta description | 原文 |
| Suno songs；Choose music → Official music 可试听 | UI 实测（官方曲目约 30 秒，Lucas/Mia/Isabella…） | 实测 |
| Ratio 9:16 / 16:9 | UI 实测 | 实测 |
| 脚本通常 10–15 分钟，可离开，在 My MVs | i18n `analyzingEta` | 原文 |
| 免费预览；完整版耗积分；失败退积分 | i18n `costDescription` | 原文 |
| 生成前会要求登录 | 游客态 "Free generations remaining: *"、Google 登录弹层、"Music added before sign-in can't be used" | **推断**（高概率） |
| 免费作品仅个人使用，商用权随会员 | FAQ + Pricing "Commercial use rights included with membership" | 原文 |
| 会员自动续费、可在 Profile 关 | Pricing 页原文 | 原文 |
| 公司名 CARDSMOOTH E-COMMERCE CO., LIMITED、隐私/条款/退款页、support@musegen.ai | 站点页脚 | 原文 |

**刻意没写**：用户数/评分/好评、价格、"free N-second preview"的具体秒数（站点用占位符，我没拿到值）、"in seconds"、stems/MIDI（站点自己写着"研发中"）、任何倒计时或名额。

## 与参考页的差异（保留了什么、砍掉了什么）

| 参考页 CloneAI | 我们 |
|---|---|
| 47 屏、20+ 题，按模板分支 | 5 题 + 结果，5 题全是产品真选项 |
| 假进度"Analyzing your answers 0%→100%" | 1.4 秒如实回显你的 5 个选择 |
| "12M+ downloads / 1M+ people / @mary1957 好评 / 83% 用户播放量涨 5 倍" | 全不用（无可核实数据） |
| 邮箱墙 + "50% off just for you" → 付费墙 → 5 个 "Only Today" 追加销售 + "Skip & Lose Offer" | 没有邮箱墙/倒计时/追加销售；只把人送到产品页，价格交给产品页自己展示 |
| 前置页内上传自拍 | 前置页不收任何东西（照片在 musegen.ai 上传） |
| 薰衣草紫 + Quicksand | MuseGen 站点的品牌色 `#050A07/#35DE7B` + Sora/Clash Display（站点同源字体，已自托管） |

## 上线前要你定的事

1. **托管**：投放需要稳定的 HTTPS 域名（TikTok 审核会访问落地页）。`site/` 整个目录直接上传即可（相对路径，放子目录也行）。我没有部署——对外发布要你点头，也需要你的账号/域名。
2. **广告落地页规则**：你之前的规定是广告直接挂 `…/rb00_1music`。把广告改挂前置页是你的决定；前置页内部最终仍走那个 slug。
3. **像素**：默认关。要开就在 `config.js` 填 code；如果受众含英国/欧盟，开像素前需要补 cookie 同意条（现在没做）。
4. **多语言**：所有文案集中在 `content.js`，加一份译文即可（站点支持 en/fr/de/es/pt/ru/zh）。
5. **插画是原创 SVG，不是产品真实输出**（页面上已写 "Illustration only"）。如果有真实 MV 截图/短片，换成真素材通常更有说服力。
6. 上面表里两处"推断"建议你确认一次。

## 目录

```
site/                 ← 这就是要上线的全部
  index.html
  assets/ app.css app.js content.js art.js config.js logo.svg fonts/*.woff2
tests/acceptance.js   ← 124 项验收
tools/                ← serve / shoot / art_sheet（开发用）+ parse_ref/fetch_screens/dump_screens/peek_*（研究参考页和站点时用）
_ref/                 ← 参考页 47 屏 HTML、站点页面/CSS/chunk、游客态 UI 截图（研究资料，可整体删除）
shots/                ← 各视口截图
```

## 我在线上站点留下的探测痕迹（日志里别当真实流量）

对 `musegen.ai` 发过几次 GET：首页、`/mv-generation`、`/pricing`、CSS/JS/字体、以及 4 次带标记的 `…/mv-generation/rb00_1music?…` 探测（`utm_campaign` 含 `TESTPRELANDER` / `CloneAI - TT - TEST`，`ttclid` 为 `PROBE123` / `PROBE456`）；
另用无头 Chrome（游客态、不点生成）打开过 `/mv-generation`、点开过 Choose music / Style template 面板。没有登录、没有生成、没有消耗任何额度。
