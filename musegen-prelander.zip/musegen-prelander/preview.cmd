@echo off
rem Local preview of the pre-lander (this PC only). Ctrl+C to stop.
rem   Phone on the same Wi-Fi:  node tools\serve.js site 8620 0.0.0.0   then open http://<this-pc-ip>:8620/
cd /d "%~dp0"
echo Open  http://127.0.0.1:8620/?utm_source=tiktok^&utm_medium=paid^&ttclid=TEST123
node tools\serve.js site 8620
