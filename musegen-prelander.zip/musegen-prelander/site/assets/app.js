/* app.js — the quiz. Plain ES5-style JS (no build, no framework) so it runs in every in-app browser.
   Flow: 5 single-choice questions (auto-advance) -> short "compose" beat -> result with a copyable brief
   -> CTA to MuseGen with the original query string (utm_*, ttclid, …) forwarded untouched. */
(function () {
  'use strict';

  var C = window.MGPL_CONTENT, CFG = window.MGPL || {}, ART = window.MGPL_ART;
  var STEPS = C.steps, N = STEPS.length;
  var KEY = 'mgpl:v1';
  var REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  var app = document.getElementById('app');
  var backBtn = document.getElementById('back');
  var countEl = document.getElementById('count');
  var fillEl = document.getElementById('fill');
  var barEl = document.getElementById('bar');
  var liveEl = document.getElementById('live');

  var state = { a: {}, view: 'q', i: 0 };
  var timer = null;
  var locked = false;

  /* ---------- tiny helpers ---------- */
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function clearTimer() { if (timer) { clearTimeout(timer); timer = null; } locked = false; }
  function valid(key, id) { return !!C.byId(C.questions[key].options, id); }
  function complete(a) {
    for (var i = 0; i < N; i++) { if (!valid(STEPS[i], a[STEPS[i]])) { return false; } }
    return true;
  }
  function firstOpen(a) {
    for (var i = 0; i < N; i++) { if (!valid(STEPS[i], a[STEPS[i]])) { return i; } }
    return N - 1;
  }

  /* ---------- session persistence (same tab + same ad URL only) ---------- */
  function save() {
    try {
      sessionStorage.setItem(KEY, JSON.stringify({ qs: location.search, a: state.a }));
    } catch (e) { /* private mode etc. */ }
  }
  function loadAnswers() {
    try {
      var s = JSON.parse(sessionStorage.getItem(KEY) || 'null');
      if (!s || s.qs !== location.search || !s.a) { return {}; }
      var out = {};
      for (var i = 0; i < N; i++) { if (valid(STEPS[i], s.a[STEPS[i]])) { out[STEPS[i]] = s.a[STEPS[i]]; } }
      return out;
    } catch (e) { return {}; }
  }

  /* ---------- analytics (all OFF unless config.js sets an id) ---------- */
  function loadTikTok(code) {
    var w = window, t = 'ttq';
    w.TiktokAnalyticsObject = t;
    var ttq = w[t] = w[t] || [];
    ttq.methods = ['page', 'track', 'identify', 'instances', 'debug', 'on', 'off', 'once', 'ready', 'alias', 'group', 'enableCookie', 'disableCookie'];
    ttq.setAndDefer = function (o, m) { o[m] = function () { o.push([m].concat(Array.prototype.slice.call(arguments, 0))); }; };
    for (var i = 0; i < ttq.methods.length; i++) { ttq.setAndDefer(ttq, ttq.methods[i]); }
    ttq.instance = function (id) {
      var e = ttq._i[id] || [];
      for (var n = 0; n < ttq.methods.length; n++) { ttq.setAndDefer(e, ttq.methods[n]); }
      return e;
    };
    ttq.load = function (id, opts) {
      var src = 'https://analytics.tiktok.com/i18n/pixel/events.js';
      ttq._i = ttq._i || {}; ttq._i[id] = []; ttq._i[id]._u = src;
      ttq._t = ttq._t || {}; ttq._t[id] = +new Date();
      ttq._o = ttq._o || {}; ttq._o[id] = opts || {};
      var s = document.createElement('script');
      s.type = 'text/javascript'; s.async = true; s.src = src + '?sdkid=' + id + '&lib=' + t;
      var f = document.getElementsByTagName('script')[0];
      f.parentNode.insertBefore(s, f);
    };
    ttq.load(code);
    ttq.page();
  }
  function loadGA(id) {
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    var s = document.createElement('script');
    s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(id);
    document.head.appendChild(s);
    window.gtag('js', new Date());
    window.gtag('config', id);
  }
  function track(name, data) {
    data = data || {};
    try { window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: name, pl: data }); } catch (e) { /* ignore */ }
    try { if (CFG.tiktokPixel && window.ttq) { window.ttq.track(name, data); } } catch (e) { /* ignore */ }
    try { if (CFG.ga4 && window.gtag) { window.gtag('event', name, data); } } catch (e) { /* ignore */ }
    try { window.dispatchEvent(new CustomEvent('mgpl:event', { detail: { name: name, data: data } })); } catch (e) { /* ignore */ }
  }

  /* ---------- destination URL: original query forwarded byte-for-byte ---------- */
  function hasKey(raw, k) {
    var s = '&' + raw + '&';
    return s.indexOf('&' + k + '=') > -1 || s.indexOf('&' + k + '&') > -1;
  }
  function withQuery(base, extra) {
    var raw = CFG.forwardQuery === false ? '' : String(location.search || '').replace(/^\?/, '').replace(/^&+|&+$/g, '');
    var parts = raw ? [raw] : [];
    if (extra) {
      for (var k in extra) {
        if (Object.prototype.hasOwnProperty.call(extra, k) && !hasKey(raw, k)) {
          parts.push(k + '=' + encodeURIComponent(extra[k]));
        }
      }
    }
    if (!parts.length) { return base; }
    return base + (base.indexOf('?') > -1 ? '&' : '?') + parts.join('&');
  }
  function picks(a) {
    return CFG.appendPicks === false ? null : { pl: 'quiz', pl_scene: a.scene, pl_genre: a.genre, pl_star: a.star, pl_song: a.song, pl_fmt: a.fmt };
  }

  /* ---------- icons ---------- */
  var TICK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5.5 12.5l4.2 4.2L18.5 7.6"/></svg>';
  var ICON = {
    me: '<circle cx="12" cy="8" r="3.6"/><path d="M4.6 20.4c.6-4 3.6-6.2 7.4-6.2s6.8 2.2 7.4 6.2"/><path d="M3 7V4.6A1.6 1.6 0 0 1 4.6 3H7M21 7V4.6A1.6 1.6 0 0 0 19.4 3H17"/>',
    ai: '<path d="M11 3.5l1.9 5 5 1.9-5 1.9-1.9 5-1.9-5-5-1.9 5-1.9z"/><path d="M19 14.5l.9 2.2 2.2.9-2.2.9-.9 2.2-.9-2.2-2.2-.9 2.2-.9z"/>',
    file: '<path d="M4 10v4M8 7v10M12 4v16M16 8v8M20 11v2"/>',
    suno: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    official: '<circle cx="12" cy="12" r="9"/><path d="M10 8.4l5.6 3.6-5.6 3.6z"/>'
  };
  function svgIcon(name) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[name] + '</svg>';
  }
  var PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M9 6.8v10.4a.8.8 0 0 0 1.2.7l8.4-5.2a.8.8 0 0 0 0-1.4L10.2 6.1A.8.8 0 0 0 9 6.8z"/></svg>';

  /* ---------- option renderers ---------- */
  function attr(o, i, sel, cls) {
    return 'type="button" class="' + cls + (sel ? ' is-on' : '') + '" role="radio" aria-checked="' + (sel ? 'true' : 'false') + '" data-id="' + o.id + '" style="--i:' + i + '"';
  }
  function optScene(o, i, sel) {
    return '<button ' + attr(o, i, sel, 'card scene') + '>' +
      '<span class="art">' + ART(o.id) + '</span>' +
      '<span class="label"><b>' + esc(o.name) + '</b><i>' + esc(o.mood) + '</i></span>' +
      '<span class="tick">' + TICK + '</span></button>';
  }
  function optChip(o, i, sel) {
    return '<button ' + attr(o, i, sel, 'card chip') + '>' +
      '<span class="chip__ico" aria-hidden="true">' + o.icon + '</span>' +
      '<span class="chip__txt">' + esc(o.name) + '</span>' +
      '<span class="tick">' + TICK + '</span></button>';
  }
  function optRow(o, i, sel) {
    return '<button ' + attr(o, i, sel, 'card row') + '>' +
      '<span class="row__ico">' + svgIcon(o.id) + '</span>' +
      '<span class="row__txt"><b>' + esc(o.name) + '</b><i>' + esc(o.desc) + '</i></span>' +
      '<span class="tick">' + TICK + '</span></button>';
  }
  function optFormat(o, i, sel) {
    return '<button ' + attr(o, i, sel, 'card fmt fmt--' + o.id) + '>' +
      '<span class="fmt__mock" aria-hidden="true"><span class="fmt__frame">' + PLAY + '</span></span>' +
      '<span class="fmt__txt"><b>' + esc(o.name) + '</b><i>' + esc(o.desc) + '</i></span>' +
      '<span class="tick">' + TICK + '</span></button>';
  }
  var RENDER = { scenes: optScene, chips: optChip, rows: optRow, formats: optFormat };

  /* ---------- screens ---------- */
  function questionHTML(i) {
    var key = STEPS[i], q = C.questions[key], fn = RENDER[q.layout], cur = state.a[key], h = '';
    for (var k = 0; k < q.options.length; k++) { h += fn(q.options[k], k, q.options[k].id === cur); }
    return '<section class="step step--' + key + '" aria-labelledby="h1">' +
      '<p class="kicker">' + esc(q.kicker) + '</p>' +
      '<h1 id="h1" tabindex="-1">' + esc(q.title) + '</h1>' +
      '<p class="sub">' + esc(q.sub) + '</p>' +
      '<div class="opts opts--' + q.layout + '" role="radiogroup" aria-labelledby="h1">' + h + '</div>' +
      '</section>';
  }

  function composeHTML() {
    var a = state.a, rows = [
      ['Scene', C.byId(C.scenes, a.scene).name],
      ['Sound', C.byId(C.genres, a.genre).name],
      ['Star', C.byId(C.stars, a.star).name],
      ['Music', C.byId(C.songs, a.song).name],
      ['Format', C.byId(C.formats, a.fmt).name]
    ], li = '';
    for (var i = 0; i < rows.length; i++) {
      li += '<li style="--i:' + i + '"><span class="recap__k">' + esc(rows[i][0]) + '</span><span class="recap__v">' + esc(rows[i][1]) + '</span><span class="recap__ok">' + TICK + '</span></li>';
    }
    return '<section class="step step--compose" aria-labelledby="h1">' +
      '<div class="spinner" aria-hidden="true"></div>' +
      '<h1 id="h1" tabindex="-1">' + esc(C.copy.composeTitle) + '</h1>' +
      '<ul class="recap">' + li + '</ul></section>';
  }

  function resultHTML() {
    var a = state.a, cp = C.copy;
    var sc = C.byId(C.scenes, a.scene), ge = C.byId(C.genres, a.genre), st = C.byId(C.stars, a.star), fm = C.byId(C.formats, a.fmt);
    var steps = C.buildSteps(a), brief = C.buildBrief(a);
    var dest = withQuery(CFG.destination, picks(a));
    var chips = '<li>' + esc(sc.name) + '</li>' + (ge.id === 'unsure' ? '' : '<li>' + esc(ge.name) + '</li>') +
      '<li>' + (st.id === 'me' ? 'Starring me' : 'AI-cast lead') + '</li><li>' + esc(fm.ratio) + '</li>';
    var ol = '', ex = '', i;
    for (i = 0; i < steps.length; i++) {
      ol += '<li><span class="n" aria-hidden="true">' + (i + 1) + '</span><div><b>' + esc(steps[i].h) + '</b><p>' + steps[i].t + '</p></div></li>';
    }
    for (i = 0; i < cp.expect.length; i++) { ex += '<li>' + cp.expect[i] + '</li>'; }
    var songMaker = '';
    if (a.song === 'official' && CFG.songMakerUrl) {
      songMaker = '<p class="aside">' + esc(cp.songMakerPrompt) + ' <a href="' + esc(withQuery(CFG.songMakerUrl, null)) + '" id="songmaker" rel="noopener">' + esc(cp.songMakerLink) + '</a></p>';
    }
    return '<section class="step step--result" aria-labelledby="h1">' +
      '<p class="kicker">' + esc(cp.resultKicker) + '</p>' +
      '<h1 id="h1" tabindex="-1">Your “' + esc(sc.name) + '” music video, ready to make</h1>' +
      '<figure class="preview preview--' + fm.id + '"><div class="preview__frame">' + ART(sc.id, fm.id === '16x9') +
      '<span class="preview__play" aria-hidden="true">' + PLAY + '</span><span class="preview__tag">' + esc(fm.ratio) + '</span></div>' +
      '<figcaption>' + esc(cp.previewCaption) + '</figcaption></figure>' +
      '<ul class="tags" aria-label="Your picks">' + chips + '</ul>' +
      '<h2>' + esc(cp.briefTitle) + '</h2>' +
      '<div class="brief" id="brief" tabindex="0">' + esc(brief) + '</div>' +
      '<div class="brief__row"><p class="hint">' + esc(cp.briefHint) + '</p>' +
      '<button type="button" class="btn btn--ghost" data-act="copy">' + esc(cp.copy) + '</button></div>' +
      '<h2>' + esc(cp.stepsTitle) + '</h2><ol class="steps">' + ol + '</ol>' + songMaker +
      '<div class="expect"><h2>' + esc(cp.expectTitle) + '</h2><ul>' + ex + '</ul></div>' +
      '<p class="fine">' + esc(cp.fine) + '</p>' +
      '<p class="again"><button type="button" class="link" data-act="again">' + esc(cp.startOver) + '</button></p>' +
      '<div class="cta-bar"><a class="btn btn--primary" id="cta" href="' + esc(dest) + '" rel="noopener">' + esc(cp.cta) + '<span class="btn__arrow" aria-hidden="true">→</span></a></div>' +
      '</section>';
  }

  /* ---------- drawing + navigation ---------- */
  function setChrome() {
    var q = state.view === 'q';
    var shown = q ? state.i + 1 : N;
    countEl.textContent = shown + '/' + N;
    var pct = q ? Math.round(((state.i + 1) / (N + 1)) * 100) : 100;
    fillEl.style.width = pct + '%';
    barEl.setAttribute('aria-valuenow', String(shown));
    backBtn.hidden = q && state.i === 0;
  }
  function draw(focus) {
    setChrome();
    app.innerHTML = state.view === 'q' ? questionHTML(state.i) : state.view === 'compose' ? composeHTML() : resultHTML();
    if (focus !== false) {
      try { window.scrollTo(0, 0); } catch (e) { /* ignore */ }
      var h = document.getElementById('h1');
      if (h) {
        try { h.focus({ preventScroll: true }); } catch (e) { h.focus(); }
        liveEl.textContent = (state.view === 'q' ? C.questions[STEPS[state.i]].kicker + '. ' : '') + h.textContent;
      }
    }
  }
  function go(view, i, replace) {
    clearTimer();
    state.view = view; state.i = i;
    var st = { v: view, i: i };
    try { if (replace) { history.replaceState(st, ''); } else { history.pushState(st, ''); } } catch (e) { /* ignore */ }
    draw(true);
    save();
    if (view === 'result') { track('PL_Result', picks(state.a) || {}); }
  }
  function compose() {
    clearTimer();
    state.view = 'compose'; state.i = N - 1;
    draw(true);
    timer = setTimeout(function () { go('result', 0, false); }, REDUCED ? 150 : 1400);
  }
  function choose(id) {
    if (locked || state.view !== 'q') { return; }
    var key = STEPS[state.i];
    if (!valid(key, id)) { return; }
    state.a[key] = id;
    locked = true;
    var btns = app.querySelectorAll('.opts [data-id]');
    for (var k = 0; k < btns.length; k++) {
      var on = btns[k].getAttribute('data-id') === id;
      btns[k].setAttribute('aria-checked', on ? 'true' : 'false');
      btns[k].classList.toggle('is-on', on);
    }
    track('PL_Pick', { step: key, value: id });
    save();
    timer = setTimeout(function () {
      locked = false; timer = null;
      if (state.i < N - 1) { go('q', state.i + 1, false); }
      else if (complete(state.a)) { compose(); }
      else { go('q', firstOpen(state.a), false); }
    }, REDUCED ? 0 : 280);
  }

  /* Copy: do the synchronous legacy copy first (it must run inside the tap, which every WebView allows),
     then the async Clipboard API, and as a last resort select the text so the person can copy it by hand. */
  function legacyCopy(text) {
    var ta = document.createElement('textarea'), ok = false;
    ta.value = text; ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;pointer-events:none';
    document.body.appendChild(ta);
    try { ta.focus(); ta.select(); ta.setSelectionRange(0, text.length); ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }
  function copyText(text, onOk, onFail) {
    if (legacyCopy(text)) { onOk(); return; }
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(onOk, onFail); return; }
    onFail();
  }
  function selectBrief() {
    var el = document.getElementById('brief');
    if (!el || !window.getSelection || !document.createRange) { return; }
    var r = document.createRange();
    r.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges(); sel.addRange(r);
  }

  /* ---------- events ---------- */
  app.addEventListener('click', function (e) {
    var el = e.target;
    while (el && el !== app && !(el.getAttribute && (el.getAttribute('data-id') || el.getAttribute('data-act') || el.id === 'cta' || el.id === 'songmaker'))) { el = el.parentNode; }
    if (!el || el === app) { return; }
    if (el.id === 'cta') { track('PL_Cta', picks(state.a) || {}); return; }
    if (el.id === 'songmaker') { track('PL_SongMaker', {}); return; }
    var act = el.getAttribute('data-act');
    if (act === 'copy') {
      var label = function (t) { el.textContent = t; try { el.focus({ preventScroll: true }); } catch (e) { /* ignore */ } setTimeout(function () { el.textContent = C.copy.copy; }, 2400); };
      copyText(C.buildBrief(state.a), function () {
        label(C.copy.copied);
        track('PL_Copy', {});
      }, function () {
        selectBrief();
        label(C.copy.copyFailed);
      });
      return;
    }
    if (act === 'again') {
      state.a = {}; save(); go('q', 0, false); return;
    }
    var id = el.getAttribute('data-id');
    if (id) { choose(id); }
  });

  backBtn.addEventListener('click', function () {
    if (state.view === 'compose') {
      /* the compose beat has no history entry of its own: just return to the last question */
      clearTimer(); state.view = 'q'; state.i = N - 1; draw(true); return;
    }
    if (window.history.length > 1 && window.history.state && window.history.state.v) { history.back(); return; }
    if (state.view === 'q' && state.i > 0) { go('q', state.i - 1, true); }
    else if (state.view !== 'q') { go('q', N - 1, true); }
  });

  window.addEventListener('popstate', function (e) {
    var s = e.state;
    if (!s || !s.v) { return; }
    clearTimer();
    state.view = s.v === 'result' ? 'result' : 'q';
    /* never show a question beyond the first unanswered one (answers can vanish: Start over, cleared storage) */
    state.i = Math.max(0, Math.min(N - 1, s.i | 0, firstOpen(state.a)));
    if (state.view === 'result' && !complete(state.a)) { state.view = 'q'; state.i = firstOpen(state.a); }
    draw(true);
  });

  /* ---------- boot ---------- */
  function boot() {
    if (CFG.tiktokPixel) { loadTikTok(CFG.tiktokPixel); }
    if (CFG.ga4) { loadGA(CFG.ga4); }
    state.a = loadAnswers();
    var hs = null;
    try { hs = history.state; } catch (e) { hs = null; }
    if (hs && hs.v) {
      state.view = hs.v === 'result' && complete(state.a) ? 'result' : 'q';
      state.i = state.view === 'result' ? 0 : Math.max(0, Math.min(N - 1, hs.i | 0, firstOpen(state.a)));
      if (state.view === 'q' && hs.v === 'result') { state.i = firstOpen(state.a); }
      draw(false);
    } else if (complete(state.a)) {
      /* same tab, same ad URL, quiz already finished (e.g. the page was reopened) -> rebuild a sane back stack */
      try {
        history.replaceState({ v: 'q', i: 0 }, '');
        for (var k = 1; k < N; k++) { history.pushState({ v: 'q', i: k }, ''); }
        history.pushState({ v: 'result', i: 0 }, '');
      } catch (e) { /* ignore */ }
      state.view = 'result'; state.i = 0;
      draw(false);
    } else {
      var start = firstOpen(state.a);
      try { history.replaceState({ v: 'q', i: 0 }, ''); for (var j = 1; j <= start; j++) { history.pushState({ v: 'q', i: j }, ''); } } catch (e) { /* ignore */ }
      state.view = 'q'; state.i = start;
      draw(false);
    }
    track('PL_Start', {});
    document.documentElement.className += ' is-ready';
  }
  boot();
})();
