/* art.js — original scene illustrations (inline SVG, no photos, no third-party art).
   Each scene returns an SVG string on a 200x240 canvas. Ids are prefixed per scene so several can sit in one page.
   Randomness is seeded, so every load draws the same picture. */
(function () {
  'use strict';

  function rng(seed) {
    var s = seed >>> 0;
    return function () {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }
  function f(n) { return Math.round(n * 10) / 10; }

  function wrap(inner) {
    return '<svg viewBox="0 0 200 240" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">' + inner + '</svg>';
  }

  /* little helpers ------------------------------------------------------- */
  function windows(r, x0, x1, y0, y1, n, colors, op) {
    var out = '';
    for (var i = 0; i < n; i++) {
      var x = x0 + r() * (x1 - x0), y = y0 + r() * (y1 - y0);
      out += '<rect x="' + f(x) + '" y="' + f(y) + '" width="2" height="3" fill="' + colors[Math.floor(r() * colors.length)] + '" opacity="' + op + '"/>';
    }
    return out;
  }
  function stars(r, n, y0, y1, color) {
    var out = '';
    for (var i = 0; i < n; i++) {
      out += '<circle class="tw" style="animation-delay:' + f(r() * 3) + 's" cx="' + f(r() * 200) + '" cy="' + f(y0 + r() * (y1 - y0)) + '" r="' + f(0.5 + r() * 0.9) + '" fill="' + color + '"/>';
    }
    return out;
  }

  /* 1. Paris dusk ---------------------------------------------------------- */
  function parisDusk() {
    var r = rng(11), i, s = '';
    s += '<defs>' +
      '<linearGradient id="pd-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b1a57"/><stop offset=".42" stop-color="#b8447f"/><stop offset=".74" stop-color="#ff8e5e"/><stop offset="1" stop-color="#ffc277"/></linearGradient>' +
      '<radialGradient id="pd-sun" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff2b8" stop-opacity=".95"/><stop offset=".45" stop-color="#ffc277" stop-opacity=".55"/><stop offset="1" stop-color="#ffc277" stop-opacity="0"/></radialGradient>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#pd-sky)"/>';
    s += '<circle cx="146" cy="172" r="54" fill="url(#pd-sun)"/><circle cx="146" cy="174" r="15" fill="#fff0c0"/>';
    s += stars(r, 14, 4, 90, '#ffe9c9');
    // birds
    s += '<path d="M40 60q4-5 8 0q4-5 8 0" fill="none" stroke="#2b1a57" stroke-width="1.2" stroke-linecap="round" opacity=".7"/>' +
      '<path d="M62 78q3-4 6 0q3-4 6 0" fill="none" stroke="#2b1a57" stroke-width="1" stroke-linecap="round" opacity=".6"/>';
    // far skyline
    s += '<path d="M0 205V190h10v-8h9v10h8v-14h7v12h10v-6h9v14h8v-10h9v8h10v-12h8v16h10v-8h9v10h8v-16h9v14h10v-8h9v12h10V240H0z" fill="#53275f" opacity=".85"/>';
    // tower: concave profile, three platforms, arch between the legs, X bracing
    s += '<path d="M88 54L89.4 82L91.6 98Q94.4 120 97.4 142Q102.4 172 108.4 196Q117 218 130 240H46Q59 218 67.6 196Q73.6 172 78.6 142Q81.6 120 84.4 98L86.6 82Z" fill="#1d1033"/>';
    s += '<path d="M62 240Q88 186 114 240z" fill="#8a4072" opacity=".75"/>';
    s += '<path d="M66.4 194.5h43.2M77 141h22M82.2 97.5h11.6" stroke="#3b2266" stroke-width="3" stroke-linecap="round"/>';
    s += '<path d="M69 196L97 142M107 196L79 142M80 142L91 98M96 142L85 98" stroke="#3b2266" stroke-width="1" opacity=".9"/>';
    // near buildings
    s += '<path d="M0 240V214h16v-9h12v9h10v-16h14v16h12v-6h10v6h12V240z" fill="#150a28"/>';
    s += '<path d="M120 240v-30h12v-10h14v10h10v-18h16v18h10v-8h8V240z" fill="#150a28"/>';
    s += windows(r, 2, 80, 200, 236, 14, ['#ffd37a', '#ffb066'], '.85');
    s += windows(r, 122, 198, 196, 236, 16, ['#ffd37a', '#ffb066'], '.85');
    // lamps along the quay
    for (i = 0; i < 6; i++) {
      var lx = 14 + i * 34;
      s += '<line x1="' + lx + '" y1="238" x2="' + lx + '" y2="224" stroke="#0b0518" stroke-width="1.2"/><circle cx="' + lx + '" cy="223" r="3.6" fill="#ffd37a" opacity=".35"/><circle cx="' + lx + '" cy="223" r="1.5" fill="#fff3c8"/>';
    }
    return wrap(s);
  }

  /* 2. Rainy Night in Tokyo ------------------------------------------------- */
  function rainyTokyo() {
    var r = rng(23), i, s = '';
    s += '<defs>' +
      '<linearGradient id="tk-bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#090620"/><stop offset=".55" stop-color="#1a0f3d"/><stop offset="1" stop-color="#2b1456"/></linearGradient>' +
      '<filter id="tk-glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#tk-bg)"/>';
    // buildings
    s += '<path d="M0 190V92h28v-14h22v36h16V70h30v44h20V84h24v26h22v-20h22V190z" fill="#120a2b"/>';
    s += '<path d="M0 190V132h18v-22h26v40h20v-30h26v18h22v-34h28v40h20V190z" fill="#0d0720" opacity=".9"/>';
    s += windows(r, 4, 196, 84, 180, 46, ['#25f5ff', '#ff3d9a', '#ffd24a', '#8a7bff'], '.55');
    // neon signs (glow copy + sharp copy)
    var signs = [
      ['<rect x="22" y="56" width="13" height="64" rx="3"/>', '#ff3d9a'],
      ['<rect x="152" y="40" width="17" height="84" rx="3"/>', '#25f5ff'],
      ['<rect x="72" y="96" width="56" height="15" rx="3"/>', '#ffd24a'],
      ['<rect x="118" y="132" width="26" height="12" rx="3"/>', '#ff3d9a']
    ];
    for (i = 0; i < signs.length; i++) {
      s += '<g fill="none" stroke="' + signs[i][1] + '" stroke-width="5" filter="url(#tk-glow)" opacity=".9">' + signs[i][0] + '</g>';
      s += '<g fill="none" stroke="' + signs[i][1] + '" stroke-width="2">' + signs[i][0] + '</g>';
    }
    s += '<path d="M27 66v44M160 52v62M79 103h42" stroke="#fff" stroke-width="1" opacity=".55"/>';
    // wet street
    s += '<rect y="188" width="200" height="52" fill="#0b0820"/>';
    s += '<g opacity=".5">' +
      '<rect x="20" y="190" width="12" height="46" fill="#ff3d9a" opacity=".35" filter="url(#tk-glow)"/>' +
      '<rect x="150" y="190" width="16" height="46" fill="#25f5ff" opacity=".35" filter="url(#tk-glow)"/>' +
      '<rect x="74" y="192" width="52" height="32" fill="#ffd24a" opacity=".22" filter="url(#tk-glow)"/></g>';
    s += '<ellipse cx="60" cy="226" rx="26" ry="3.4" fill="#25f5ff" opacity=".18"/><ellipse cx="140" cy="232" rx="30" ry="3.4" fill="#ff3d9a" opacity=".2"/>';
    // umbrella figure
    s += '<path d="M84 190a16 14 0 0 1 32 0z" fill="#ff3d9a"/><path d="M84 190a16 4 0 0 0 8 3a8 4 0 0 0 8 0a8 4 0 0 0 8 0a8 4 0 0 0 8-3z" fill="#c42a78"/>';
    s += '<line x1="100" y1="190" x2="100" y2="206" stroke="#0b0820" stroke-width="1.4"/>';
    s += '<circle cx="104" cy="198" r="4.4" fill="#0b0820"/><path d="M97 204h14l3 26h-20z" fill="#0b0820"/>';
    // rain
    s += '<g class="rain" stroke="#c8d6ff" stroke-width=".8" opacity=".38">';
    for (i = 0; i < 70; i++) {
      var rx = r() * 220 - 10, ry = r() * 280 - 50;
      s += '<line x1="' + f(rx) + '" y1="' + f(ry) + '" x2="' + f(rx - 3) + '" y2="' + f(ry + 12) + '"/>';
    }
    s += '</g>';
    return wrap(s);
  }

  /* 3. Arena Rock ------------------------------------------------------------ */
  function arenaRock() {
    var r = rng(37), i, s = '';
    s += '<defs>' +
      '<linearGradient id="ar-bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a0306"/><stop offset=".6" stop-color="#2a0a12"/><stop offset="1" stop-color="#4a1018"/></linearGradient>' +
      '<linearGradient id="ar-beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>' +
      '<filter id="ar-blur" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="6"/></filter>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#ar-bg)"/>';
    // beams (drawn first so the truss sits on top)
    var beams = [[30, 18, -10, 214, 52, '#ff4d4d'], [66, 18, 40, 214, 86, '#ffd27a'], [100, 18, 100, 214, 100, '#ffffff'], [134, 18, 160, 214, 168, '#ffd27a'], [170, 18, 210, 214, 150, '#ff4d4d']];
    s += '<g style="mix-blend-mode:screen">';
    for (i = 0; i < beams.length; i++) {
      var b = beams[i];
      s += '<polygon points="' + (b[0] - 3) + ',' + b[1] + ' ' + (b[0] + 3) + ',' + b[1] + ' ' + b[4] + ',' + b[3] + ' ' + b[2] + ',' + b[3] + '" fill="url(#ar-beam)" opacity=".5"/>';
    }
    s += '</g>';
    s += '<ellipse cx="100" cy="176" rx="90" ry="26" fill="#ff6a5a" opacity=".28" filter="url(#ar-blur)"/>';
    // truss
    s += '<rect x="0" y="12" width="200" height="5" fill="#23232b"/>';
    for (i = 0; i < 5; i++) { s += '<circle cx="' + beams[i][0] + '" cy="19" r="4" fill="#fff7d6"/><circle cx="' + beams[i][0] + '" cy="19" r="8" fill="#fff7d6" opacity=".25"/>'; }
    // stage + lead
    s += '<rect x="0" y="176" width="200" height="12" fill="#17080c"/><rect x="0" y="176" width="200" height="1.6" fill="#ff6a5a" opacity=".6"/>';
    s += '<circle cx="100" cy="140" r="6" fill="#06020a"/><path d="M92 148h16l5 30H87z" fill="#06020a"/>';
    s += '<path d="M108 154l22-26" stroke="#06020a" stroke-width="3" stroke-linecap="round"/><path d="M92 154l-8-10" stroke="#06020a" stroke-width="3" stroke-linecap="round"/>';
    s += '<path d="M96 168l-18-6" stroke="#06020a" stroke-width="5" stroke-linecap="round"/><rect x="62" y="156" width="20" height="9" rx="3" transform="rotate(-8 72 160)" fill="#06020a"/>';
    // crowd
    s += '<g fill="#090204">';
    for (i = 0; i < 17; i++) {
      var cx = i * 12.5 + r() * 4;
      s += '<circle cx="' + f(cx) + '" cy="' + f(206 + r() * 6) + '" r="' + f(5 + r() * 1.5) + '"/><rect x="' + f(cx - 6) + '" y="' + f(211 + r() * 4) + '" width="12" height="40" rx="5"/>';
    }
    s += '</g>';
    s += '<g stroke="#090204" stroke-width="2.4" stroke-linecap="round">';
    for (i = 0; i < 9; i++) {
      var hx = 8 + i * 23 + r() * 6, hh = 12 + r() * 10;
      s += '<line x1="' + f(hx) + '" y1="214" x2="' + f(hx + (r() * 6 - 3)) + '" y2="' + f(214 - hh) + '"/>';
    }
    s += '</g>';
    s += '<g fill="#030102">';
    for (i = 0; i < 12; i++) { var fx = i * 18 + r() * 6; s += '<circle cx="' + f(fx) + '" cy="' + f(232 + r() * 4) + '" r="' + f(7 + r() * 2) + '"/>'; }
    s += '<rect y="236" width="200" height="8"/></g>';
    return wrap(s);
  }

  /* 4. Cliff Piano ----------------------------------------------------------- */
  function cliffPiano() {
    var r = rng(53), i, s = '';
    s += '<defs>' +
      '<linearGradient id="cp-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2b53"/><stop offset=".4" stop-color="#7d3c98"/><stop offset=".72" stop-color="#ff7a59"/><stop offset="1" stop-color="#ffc477"/></linearGradient>' +
      '<linearGradient id="cp-sea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a3f86"/><stop offset="1" stop-color="#10153a"/></linearGradient>' +
      '<radialGradient id="cp-sun" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff0c0" stop-opacity=".9"/><stop offset="1" stop-color="#ffb070" stop-opacity="0"/></radialGradient>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#cp-sky)"/>';
    s += stars(r, 16, 4, 70, '#fff1d6');
    s += '<circle cx="64" cy="150" r="52" fill="url(#cp-sun)"/><circle cx="64" cy="152" r="20" fill="#ffe3a0"/>';
    s += '<rect y="150" width="200" height="90" fill="url(#cp-sea)"/>';
    s += '<rect y="148" width="200" height="3" fill="#ffd9a0" opacity=".35"/>';
    for (i = 0; i < 12; i++) {
      var w = 40 - i * 2.6, y = 154 + i * 6.2;
      s += '<rect x="' + f(64 - w / 2) + '" y="' + f(y) + '" width="' + f(w) + '" height="1.8" rx=".9" fill="#ffd9a0" opacity="' + f(0.5 - i * 0.03) + '"/>';
    }
    // gulls
    s += '<path d="M118 70q4-5 8 0q4-5 8 0" fill="none" stroke="#1d1033" stroke-width="1.2" stroke-linecap="round" opacity=".75"/>' +
      '<path d="M146 88q3-4 6 0q3-4 6 0" fill="none" stroke="#1d1033" stroke-width="1" stroke-linecap="round" opacity=".65"/>';
    // cliff
    s += '<path d="M96 240V186q10-18 34-20q20-2 30-12l40-8V240z" fill="#0f0a1f"/>';
    s += '<path d="M120 168q10-4 22-6q18-2 28-10l30-6" fill="none" stroke="#2d1f4a" stroke-width="2" stroke-linecap="round"/>';
    // grand piano silhouette
    s += '<g fill="#05030c">' +
      '<path d="M128 156h46q4 0 4 4v3h-54v-3q0-4 4-4z"/>' +
      '<path d="M130 156l6-24q1-3 4-3l34 6q4 1 4 5v16z"/>' +
      '<rect x="134" y="162" width="3" height="14"/><rect x="164" y="162" width="3" height="14"/><rect x="170" y="162" width="3" height="10"/>' +
      '<rect x="112" y="158" width="12" height="4" rx="1.5"/><rect x="116" y="162" width="2.4" height="12"/>' +
      '</g>';
    s += '<path d="M138 140l30 4" stroke="#3b2266" stroke-width="1" opacity=".6"/>';
    // pianist
    s += '<circle cx="118" cy="146" r="4.6" fill="#05030c"/><path d="M113 151h10l2 9h-14z" fill="#05030c"/><path d="M123 153l8 4" stroke="#05030c" stroke-width="2.4" stroke-linecap="round"/>';
    return wrap(s);
  }

  /* 5. Road Trip in Camper Van ------------------------------------------------ */
  function roadTrip() {
    var s = '';
    s += '<defs>' +
      '<linearGradient id="rt-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4c5ed2"/><stop offset=".45" stop-color="#ff9a6b"/><stop offset="1" stop-color="#ffdc92"/></linearGradient>' +
      '<linearGradient id="rt-ground" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2a52"/><stop offset="1" stop-color="#150f26"/></linearGradient>' +
      '<radialGradient id="rt-sun" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff6d2" stop-opacity=".95"/><stop offset="1" stop-color="#ffd37a" stop-opacity="0"/></radialGradient>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#rt-sky)"/>';
    s += '<circle cx="100" cy="126" r="58" fill="url(#rt-sun)"/><circle cx="100" cy="128" r="22" fill="#fff4c9"/>';
    s += '<path d="M0 138l26-34l20 22l22-30l24 36l18-22l26 30l24-28l20 26v34H0z" fill="#8b5fa8" opacity=".85"/>';
    s += '<path d="M0 144l30-24l22 18l26-24l26 28l22-18l30 26l44-22v48H0z" fill="#5b3a86"/>';
    s += '<rect y="140" width="200" height="100" fill="url(#rt-ground)"/>';
    s += '<polygon points="98,140 102,140 188,240 12,240" fill="#1c1630"/>';
    s += '<polygon points="98,140 99,140 12,240 6,240" fill="#ffd78c" opacity=".35"/><polygon points="101,140 102,140 194,240 188,240" fill="#ffd78c" opacity=".35"/>';
    s += '<line class="dash" x1="100" y1="142" x2="100" y2="240" stroke="#ffd78c" stroke-width="2.2" stroke-dasharray="7 9" opacity=".9"/>';
    // poles
    s += '<g stroke="#0e0a1c" stroke-width="1.4"><line x1="70" y1="156" x2="70" y2="140"/><line x1="130" y1="156" x2="130" y2="140"/><line x1="46" y1="196" x2="46" y2="164"/><line x1="154" y1="196" x2="154" y2="164"/></g>';
    s += '<path d="M46 166Q100 178 154 166M70 142Q100 148 130 142" fill="none" stroke="#0e0a1c" stroke-width=".7" opacity=".8"/>';
    // camper van
    s += '<g transform="translate(81 150) scale(.82)">' +
      '<ellipse cx="22" cy="23" rx="24" ry="3" fill="#000" opacity=".35"/>' +
      '<rect x="0" y="4" width="44" height="18" rx="5" fill="#f2e6d0"/>' +
      '<path d="M44 12h-6l-5-8h6q5 0 5 4z" fill="#f2e6d0"/>' +
      '<rect x="0" y="12" width="44" height="3" fill="#35DE7B"/>' +
      '<rect x="6" y="6" width="9" height="6" rx="1.5" fill="#7fc4ff"/><rect x="18" y="6" width="9" height="6" rx="1.5" fill="#7fc4ff"/><path d="M33 6h4l3 6h-7z" fill="#7fc4ff"/>' +
      '<rect x="4" y="1" width="26" height="3" rx="1" fill="#6a5a46"/>' +
      '<circle cx="11" cy="22" r="4.4" fill="#111"/><circle cx="11" cy="22" r="1.6" fill="#888"/><circle cx="34" cy="22" r="4.4" fill="#111"/><circle cx="34" cy="22" r="1.6" fill="#888"/>' +
      '<circle cx="46" cy="14" r="2.4" fill="#fff3b0"/><path d="M46 14l16-5v12z" fill="#fff3b0" opacity=".25"/>' +
      '</g>';
    return wrap(s);
  }

  /* 6. Sunset grassland -------------------------------------------------------- */
  function sunsetGrass() {
    var r = rng(71), i, s = '';
    s += '<defs>' +
      '<linearGradient id="sg-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e85d6f"/><stop offset=".5" stop-color="#ff9d6c"/><stop offset="1" stop-color="#ffd98a"/></linearGradient>' +
      '<radialGradient id="sg-sun" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff7d6" stop-opacity=".95"/><stop offset="1" stop-color="#ffe08a" stop-opacity="0"/></radialGradient>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#sg-sky)"/>';
    s += '<circle cx="104" cy="132" r="64" fill="url(#sg-sun)"/><circle cx="104" cy="134" r="24" fill="#fff4c4"/>';
    s += '<path d="M10 70q18-8 40 0q-14 5-40 0zM140 52q22-9 46 0q-18 6-46 0z" fill="#fff" opacity=".28"/>';
    s += '<path d="M0 150q40-22 90-10t110-8V240H0z" fill="#9a7f3a"/>';
    s += '<path d="M0 174q50-24 100-10t100-6V240H0z" fill="#6c7a34"/>';
    s += '<path d="M0 200q60-22 120-8t80-4V240H0z" fill="#41592b"/>';
    // lone tree
    s += '<g transform="translate(150 150)"><path d="M0 22v-18" stroke="#1d2a14" stroke-width="2.6" stroke-linecap="round"/>' +
      '<circle cx="0" cy="-2" r="11" fill="#223319"/><circle cx="-8" cy="3" r="7" fill="#223319"/><circle cx="8" cy="3" r="7.5" fill="#223319"/></g>';
    // foreground grass blades
    s += '<g stroke="#1b2a14" stroke-linecap="round" stroke-width="1.3">';
    for (i = 0; i < 90; i++) {
      var gx = r() * 200, gy = 206 + r() * 36, gl = 7 + r() * 11, ang = (r() - 0.5) * 0.6;
      s += '<line x1="' + f(gx) + '" y1="' + f(gy) + '" x2="' + f(gx + Math.sin(ang) * gl) + '" y2="' + f(gy - Math.cos(ang) * gl) + '"/>';
    }
    s += '</g>';
    // fireflies
    for (i = 0; i < 12; i++) {
      s += '<circle class="tw" style="animation-delay:' + f(r() * 3) + 's" cx="' + f(r() * 200) + '" cy="' + f(160 + r() * 70) + '" r="1.3" fill="#fff3a8"/>';
    }
    return wrap(s);
  }

  /* 7. Street Rap --------------------------------------------------------------- */
  function streetRap() {
    var r = rng(89), i, s = '';
    s += '<defs>' +
      '<linearGradient id="sr-bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a1030"/><stop offset="1" stop-color="#341a5c"/></linearGradient>' +
      '<linearGradient id="sr-eq" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#25f5b4"/><stop offset="1" stop-color="#35de7b"/></linearGradient>' +
      '<linearGradient id="sr-cone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd37a" stop-opacity=".55"/><stop offset="1" stop-color="#ffd37a" stop-opacity="0"/></linearGradient>' +
      '<filter id="sr-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.6"/></filter>' +
      '<pattern id="sr-brick" width="24" height="12" patternUnits="userSpaceOnUse"><path d="M0 .5h24M0 6.5h24M12 .5v6M0 6.5v6M24 6.5v6" stroke="#fff" stroke-width=".6" opacity=".06" fill="none"/></pattern>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#sr-bg)"/><rect width="200" height="196" fill="url(#sr-brick)"/>';
    // spray tags
    var tags = [
      ['M18 62C44 28 66 96 98 58S152 40 184 74', '#ff3d9a', 7],
      ['M26 112C58 90 78 134 118 106S162 114 178 98', '#25f5ff', 5],
      ['M44 150C70 138 92 158 128 146', '#ffd24a', 4]
    ];
    for (i = 0; i < tags.length; i++) {
      s += '<path d="' + tags[i][0] + '" fill="none" stroke="' + tags[i][1] + '" stroke-width="' + (tags[i][2] + 4) + '" stroke-linecap="round" filter="url(#sr-glow)" opacity=".7"/>';
      s += '<path d="' + tags[i][0] + '" fill="none" stroke="' + tags[i][1] + '" stroke-width="' + tags[i][2] + '" stroke-linecap="round"/>';
    }
    s += '<path d="M22 62C46 34 66 90 98 58S150 44 180 72" fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round" opacity=".45"/>';
    // streetlamp
    s += '<polygon points="26,52 14,196 70,196" fill="url(#sr-cone)"/>';
    s += '<rect x="24" y="52" width="3" height="150" fill="#0b0716"/><path d="M26 52h12q4 0 4 4v2H26z" fill="#0b0716"/><circle cx="36" cy="60" r="3" fill="#ffe6a0"/>';
    // ground
    s += '<rect y="194" width="200" height="46" fill="#0d0818"/><rect y="194" width="200" height="1.4" fill="#35de7b" opacity=".5"/>';
    // figure with cap
    s += '<circle cx="112" cy="154" r="8.4" fill="#06030c"/><path d="M103 152q9-12 19 0z" fill="#06030c"/><rect x="118" y="151" width="10" height="3" rx="1.4" fill="#06030c"/>';
    s += '<path d="M101 164h22l5 32h-32z" fill="#06030c"/><path d="M124 170l14-12" stroke="#06030c" stroke-width="4" stroke-linecap="round"/><circle cx="141" cy="155" r="2.6" fill="#06030c"/>';
    // equalizer
    var hs = [14, 26, 18, 34, 22, 40, 28, 36, 20, 30, 16, 24, 12, 22];
    for (i = 0; i < hs.length; i++) {
      s += '<rect class="eq" style="animation-delay:' + f(i * 0.11) + 's" x="' + (8 + i * 13.6) + '" y="' + (240 - hs[i]) + '" width="8" height="' + hs[i] + '" rx="2" fill="url(#sr-eq)" opacity=".9"/>';
    }
    return wrap(s);
  }

  /* 8. Village Under Starry Sky (painterly) ---------------------------------------- */
  function starryVillage() {
    var r = rng(97), i, s = '';
    s += '<defs>' +
      '<linearGradient id="sv-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0b1a4a"/><stop offset=".6" stop-color="#14307a"/><stop offset="1" stop-color="#2a56b0"/></linearGradient>' +
      '<radialGradient id="sv-glow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#ffe27a" stop-opacity=".8"/><stop offset="1" stop-color="#ffe27a" stop-opacity="0"/></radialGradient>' +
      '</defs>';
    s += '<rect width="200" height="240" fill="url(#sv-sky)"/>';
    // brush strokes
    s += '<g fill="none" stroke-linecap="round">';
    for (i = 0; i < 46; i++) {
      var bx = r() * 200, by = r() * 170, bl = 8 + r() * 16, bc = r() > 0.55 ? '#8fb8ff' : '#4f7fd8';
      s += '<path d="M' + f(bx) + ' ' + f(by) + 'q' + f(bl / 2) + ' ' + f(-3 + r() * 6) + ' ' + f(bl) + ' ' + f(-2 + r() * 4) + '" stroke="' + bc + '" stroke-width="1.6" opacity="' + f(0.16 + r() * 0.2) + '"/>';
    }
    s += '</g>';
    // swirls
    function swirl(cx, cy, rad, col) {
      var o = '';
      for (var k = 0; k < 4; k++) {
        o += '<circle cx="' + cx + '" cy="' + cy + '" r="' + f(rad - k * (rad / 5)) + '" fill="none" stroke="' + col + '" stroke-width="' + f(2.4 - k * 0.4) + '" stroke-dasharray="' + f(rad * 3.2) + ' ' + f(rad * 1.4) + '" stroke-linecap="round" opacity="' + f(0.55 - k * 0.1) + '" transform="rotate(' + (k * 70) + ' ' + cx + ' ' + cy + ')"/>';
      }
      return o;
    }
    s += swirl(54, 70, 34, '#9fc4ff') + swirl(132, 52, 26, '#7fa9f0');
    // moon
    s += '<circle cx="142" cy="34" r="22" fill="url(#sv-glow)"/><path d="M142 21a13 13 0 1 0 7 24a10 10 0 1 1-7-24z" fill="#ffe27a"/>';
    // stars with halos
    var st = [[90, 24], [116, 92], [30, 28], [178, 88], [70, 120], [150, 126], [14, 96]];
    for (i = 0; i < st.length; i++) {
      s += '<circle cx="' + st[i][0] + '" cy="' + st[i][1] + '" r="7" fill="url(#sv-glow)"/><circle class="tw" style="animation-delay:' + f(i * 0.4) + 's" cx="' + st[i][0] + '" cy="' + st[i][1] + '" r="2" fill="#fff3b0"/>';
    }
    // hills + village (lifted so the houses sit above the label strip)
    s += '<rect y="200" width="200" height="44" fill="#0a1236"/><g transform="translate(0 -26)">';
    s += '<path d="M0 176q40-26 84-10t116-12V240H0z" fill="#0f1a45"/>';
    s += '<path d="M0 204q50-18 110-6t90-4V240H0z" fill="#0a1236"/>';
    var houses = [[24, 186, 20, 16], [52, 190, 16, 14], [84, 182, 22, 18], [118, 188, 18, 15], [146, 184, 24, 17]];
    for (i = 0; i < houses.length; i++) {
      var h = houses[i];
      s += '<rect x="' + h[0] + '" y="' + h[1] + '" width="' + h[2] + '" height="' + h[3] + '" fill="#101a47"/><polygon points="' + (h[0] - 2) + ',' + h[1] + ' ' + (h[0] + h[2] / 2) + ',' + (h[1] - 9) + ' ' + (h[0] + h[2] + 2) + ',' + h[1] + '" fill="#070d2b"/>';
      s += '<rect x="' + (h[0] + 4) + '" y="' + (h[1] + 5) + '" width="4" height="5" fill="#ffd36b"/>';
      if (h[2] > 18) { s += '<rect x="' + (h[0] + h[2] - 9) + '" y="' + (h[1] + 5) + '" width="4" height="5" fill="#ffd36b"/>'; }
    }
    // spire + cypress
    s += '<path d="M104 160l4 24h-8z" fill="#070d2b"/><rect x="100" y="182" width="12" height="12" fill="#101a47"/><rect x="104" y="186" width="3" height="5" fill="#ffd36b"/>';
    s += '<path d="M176 240q-12-30-2-72q12 36 2 72z" fill="#050a22"/><path d="M12 240q-10-26-1-60q10 30 1 60z" fill="#050a22"/>';
    s += '</g>';
    // foreground: a winding lane up to the village, two lanterns
    s += '<path d="M-4 240Q46 214 92 226T196 206V240z" fill="#0c1640"/>';
    s += '<path d="M104 240q-30-14-6-24q22-8 6-20" fill="none" stroke="#3a5ec0" stroke-width="3" stroke-linecap="round" opacity=".5"/>';
    s += '<line x1="60" y1="236" x2="60" y2="220" stroke="#050a22" stroke-width="1.6"/><circle cx="60" cy="219" r="7" fill="url(#sv-glow)"/><circle cx="60" cy="219" r="2" fill="#ffe9a0"/>';
    s += '<line x1="150" y1="238" x2="150" y2="224" stroke="#050a22" stroke-width="1.6"/><circle cx="150" cy="223" r="7" fill="url(#sv-glow)"/><circle cx="150" cy="223" r="2" fill="#ffe9a0"/>';
    return wrap(s);
  }

  var ART = {
    'paris-dusk': parisDusk,
    'rainy-tokyo': rainyTokyo,
    'arena-rock': arenaRock,
    'cliff-piano': cliffPiano,
    'road-trip': roadTrip,
    'sunset-grass': sunsetGrass,
    'street-rap': streetRap,
    'starry-village': starryVillage
  };
  var cache = {};
  /* In a 16:9 frame the 200x240 canvas is cropped to a 200x112.5 band. Most scenes read fine from the middle;
     these override the window (viewBox) where the middle band hides the subject. */
  var WIDE_VIEWBOX = { 'paris-dusk': '0 76 200 112.5' };
  window.MGPL_ART = function (id, wide) {
    if (!ART[id]) { return ''; }
    var svg = cache[id] || (cache[id] = ART[id]());
    if (wide && WIDE_VIEWBOX[id]) { return svg.replace('viewBox="0 0 200 240"', 'viewBox="' + WIDE_VIEWBOX[id] + '"'); }
    return svg;
  };
})();
