/* config.js — the only file you normally need to edit. No build step. */
window.MGPL = {
  /* Where the final button goes. Keep the promo slug (rb00_1music): MuseGen's server reads it, sets the
     ttclid / promo-code cookies, then 307-redirects to /mv-generation with the full query string intact. */
  destination: 'https://www.musegen.ai/mv-generation/rb00_1music',

  /* Quiet second link, shown only to people who said they'd "try an official track". */
  songMakerUrl: 'https://www.musegen.ai/ai-song-maker',

  /* Forward every incoming query param (utm_*, ttclid, …) to the destination, byte for byte. */
  forwardQuery: true,

  /* Also append the quiz picks as pl=quiz&pl_scene=…&pl_genre=…&pl_star=…&pl_song=…&pl_fmt=…
     (MuseGen ignores them in its first-landing cookie; GA/other tools can still read them from the URL). */
  appendPicks: true,

  /* Analytics. An empty string means OFF — nothing third-party loads and nothing is sent anywhere. */
  tiktokPixel: '',   /* e.g. 'DBHGIPBC77U8K2BMJ8NG' (Ai music-Test). Fires custom events PL_Start / PL_Pick / PL_Result / PL_Copy / PL_Cta */
  ga4: ''            /* e.g. 'G-XXXXXXXXXX' */
};
