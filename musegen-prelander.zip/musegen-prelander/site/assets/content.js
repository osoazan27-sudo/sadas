/* content.js — every word on the page + the option data.
   Product facts used here (checked against musegen.ai on 2026-11-13) are listed in README.md > "Claims table".
   Nothing here is invented social proof: no user counts, no ratings, no countdowns. */
(function () {
  'use strict';

  /* Names are MuseGen's real "Style template" names (MV page > Style template). The mood line and the
     brief sentence are our own creative wording, not a description of what the template contains. */
  var SCENES = [
    { id: 'paris-dusk', name: 'Paris dusk', mood: 'Golden, romantic',
      brief: 'Golden-hour Paris at dusk: lamplit bridges, café terraces and the skyline glowing behind the lead.' },
    { id: 'rainy-tokyo', name: 'Rainy Night in Tokyo', mood: 'Neon, rain, reflections',
      brief: 'A rainy night in Tokyo: neon signs, wet streets full of reflections, umbrellas and slow, moody camera moves.' },
    { id: 'arena-rock', name: 'Arena Rock', mood: 'Big stage, big crowd',
      brief: 'A huge arena show: stage lights, haze, a roaring crowd and sweeping camera moves on every chorus.' },
    { id: 'cliff-piano', name: 'Cliff Piano', mood: 'Cinematic, emotional',
      brief: 'A piano on a windswept seaside cliff at sunset, waves below, slow cinematic push-ins on the emotional lines.' },
    { id: 'road-trip', name: 'Road Trip in Camper Van', mood: 'Free-spirited, sunny',
      brief: 'A camper-van road trip: open highway, golden-hour light, windows down, quick cuts on the beat.' },
    { id: 'sunset-grass', name: 'Sunset grassland', mood: 'Warm, wide-open',
      brief: 'A wide grassland at sunset: warm light, drifting grass, golden close-ups and gentle, free-spirited motion.' },
    { id: 'street-rap', name: 'Street Rap', mood: 'Raw, rhythmic',
      brief: 'Late-night street scenes: graffiti walls, streetlights, the crew around the lead, hard cuts on the snare.' },
    { id: 'starry-village', name: 'Village Under Starry Sky', mood: 'Dreamy, painterly',
      brief: 'A painterly village under a swirling starry sky: lantern-lit rooftops, soft brush-stroke motion, dreamy pacing.' }
  ];

  /* The first seven are MuseGen's own genre groups (AI Song Maker). */
  var GENRES = [
    { id: 'pop', name: 'Pop & Vocals', icon: '🎤',
      brief: 'Bright, catchy pop energy — keep the lead’s face and expressions front and center.' },
    { id: 'hiphop', name: 'Hip-Hop & Rap', icon: '🧢',
      brief: 'Hip-hop swagger — confident posture and rhythmic cuts that land on the beat.' },
    { id: 'edm', name: 'EDM & Electronic', icon: '🎧',
      brief: 'Electronic build-and-drop energy — let the visuals surge on the drops.' },
    { id: 'lofi', name: 'Lo-Fi & Chill Beats', icon: '☕',
      brief: 'Lo-fi calm — soft light, slow pacing and cozy details.' },
    { id: 'jazz', name: 'Jazz & Soul', icon: '🎷',
      brief: 'Jazz and soul warmth — intimate, smoky and unhurried.' },
    { id: 'classical', name: 'Classical & Orchestral', icon: '🎻',
      brief: 'Orchestral sweep — grand, elegant and slow-building.' },
    { id: 'cinematic', name: 'Cinematic & Soundtracks', icon: '🎬',
      brief: 'Cinematic score — epic scale, dramatic lighting and an emotional arc.' },
    { id: 'unsure', name: 'Not sure yet', icon: '🤷',
      brief: 'Let the pacing and mood follow the song.' }
  ];

  var STARS = [
    { id: 'me', name: 'Me', desc: 'Add one clear, front-facing photo — your character stays consistent across shots.',
      tab: 'Image to Video',
      brief: 'One lead character based on my uploaded photo, looking the same in every shot.' },
    { id: 'ai', name: 'Let AI cast the lead', desc: 'No photo needed. MuseGen designs the lead character for you.',
      tab: 'Music to Video',
      brief: 'One AI-designed lead character who stays consistent across every shot.' }
  ];

  var SONGS = [
    { id: 'file', name: 'I have a song file', desc: 'Upload an MP3, WAV or M4A.' },
    { id: 'suno', name: 'My song is on Suno', desc: 'Pick it from “Suno songs”.' },
    { id: 'official', name: 'I’ll try an official track', desc: 'No song needed — MuseGen has ready-made tracks you can preview.' }
  ];

  var FORMATS = [
    { id: '9x16', name: 'Vertical 9:16', desc: 'TikTok · Reels · Shorts', ratio: '9:16',
      brief: 'Vertical 9:16 framing for TikTok, Reels and Shorts.' },
    { id: '16x9', name: 'Widescreen 16:9', desc: 'YouTube', ratio: '16:9',
      brief: 'Widescreen 16:9 framing.' }
  ];

  var QUESTIONS = {
    scene: {
      kicker: 'Step 1 of 5 · Scene',
      title: 'Where should your music video take place?',
      sub: 'Five quick picks, then MuseGen turns your song into a music video. Tap a scene to start.',
      layout: 'scenes', options: SCENES
    },
    genre: {
      kicker: 'Step 2 of 5 · Sound',
      title: 'What does your song sound like?',
      sub: 'Pick the closest vibe — it shapes the pacing of your video.',
      layout: 'chips', options: GENRES
    },
    star: {
      kicker: 'Step 3 of 5 · Star',
      title: 'Who’s the star of the video?',
      sub: 'You’ll add any photo on MuseGen — nothing is uploaded on this page.',
      layout: 'rows', options: STARS
    },
    song: {
      kicker: 'Step 4 of 5 · Music',
      title: 'Where’s your song?',
      sub: 'No song yet? Try one of MuseGen’s official tracks.',
      layout: 'rows', options: SONGS
    },
    fmt: {
      kicker: 'Step 5 of 5 · Format',
      title: 'Where will you post it?',
      sub: 'This sets the frame shape. You can still change it on MuseGen.',
      layout: 'formats', options: FORMATS
    }
  };

  function byId(list, id) {
    for (var i = 0; i < list.length; i++) { if (list[i].id === id) { return list[i]; } }
    return null;
  }

  /* The text people paste into MuseGen's "Description" box (limit there: 1000 characters). */
  function buildBrief(a) {
    var sc = byId(SCENES, a.scene), ge = byId(GENRES, a.genre), st = byId(STARS, a.star), fm = byId(FORMATS, a.fmt);
    return [sc.brief, ge.brief, st.brief, fm.brief].join(' ');
  }

  /* The three "what to tap on MuseGen" steps, tailored to the answers. Strings are constants (safe to inject). */
  function buildSteps(a) {
    var sc = byId(SCENES, a.scene), st = byId(STARS, a.star), fm = byId(FORMATS, a.fmt);
    var music = {
      file: 'Tap <b>Upload music</b> and add your MP3, WAV or M4A.',
      suno: 'Tap <b>Suno songs</b> and pick your track.',
      official: 'Tap <b>Choose music</b> → <b>Official music</b> and preview a track you like.'
    }[a.song];
    var star = a.star === 'me'
      ? 'Stay on <b>Image to Video</b> and tap <b>Upload photo</b> — use a clear, front-facing photo (no blur, no side angles).'
      : 'Switch to the <b>Music to Video</b> tab — no photo needed.';
    var look = 'Tap <b>Style template</b> and choose “' + sc.name + '” — or paste your brief into <b>Description</b>. Set <b>Ratio</b> to ' + fm.ratio + ', then tap <b>Generate Script</b>.';
    return [
      { h: 'Add your music', t: music },
      { h: st.id === 'me' ? 'Add your photo' : 'Skip the photo', t: star },
      { h: 'Set the look & go', t: look }
    ];
  }

  window.MGPL_CONTENT = {
    steps: ['scene', 'genre', 'star', 'song', 'fmt'],
    questions: QUESTIONS,
    scenes: SCENES, genres: GENRES, stars: STARS, songs: SONGS, formats: FORMATS,
    byId: byId, buildBrief: buildBrief, buildSteps: buildSteps,
    copy: {
      composeTitle: 'Putting your brief together…',
      resultKicker: 'Your brief is ready',
      previewCaption: 'Illustration only — MuseGen generates your actual video from your song.',
      briefTitle: 'Your description',
      briefHint: 'Paste this into the Description box on MuseGen (it’s editable there).',
      stepsTitle: 'Three taps on MuseGen',
      expectTitle: 'What to expect',
      expect: [
        'You’ll be asked to sign in before you generate.',
        'MuseGen’s AI agent writes the script first — usually 10–15 minutes. You can leave and come back; it’s saved under <b>My MVs</b>.',
        'You get a short preview video free. The full-length video uses credits, and if creation fails the credits are refunded.'
      ],
      cta: 'Open MuseGen — free to start',
      songMakerPrompt: 'Rather write a brand-new song first?',
      songMakerLink: 'Try the AI Song Maker →',
      fine: 'AI-generated video. Free creations are for personal use — commercial rights come with a paid membership. Memberships renew automatically until you cancel them in your profile.',
      copy: 'Copy brief', copied: 'Copied ✓', copyFailed: 'Selected — copy it', startOver: 'Start over'
    }
  };
})();
