@echo off
rem Full acceptance run (headless Chrome, throw-away profile, never leaves localhost).
cd /d "%~dp0"
node tests\acceptance.js
