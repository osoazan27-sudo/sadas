'use strict';
/* node tests/acceptance.js
   End-to-end acceptance for the MuseGen pre-lander. Starts its own static server on a random port, drives a
   throw-away headless Chrome (never touches open browser windows), prints PASS/FAIL per check, exits 1 on any FAIL.
   The expected values (brief sentences, step wording, URL layout) are re-derived here from the spec, not read
   back from the page's own helpers, except where a check says it is a consistency sweep. */
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

let puppeteer;
try { puppeteer = require('puppeteer-core'); } catch (e) { puppeteer = require('C:/Users/Administrator/used-iphone-store-tools/node_modules/puppeteer-core'); }

const SITE = path.resolve(__dirname, '..', 'site');
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.woff2': 'font/woff2' };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const DEST = 'https://www.musegen.ai/mv-generation/rb00_1music';
const TT_QUERY = 'utm_source=tiktok&utm_id=1879111239386114&utm_campaign=MuseGen%20-%20TT%20-%20US%20-%20Prelander%20Test&utm_medium=paid&ttclid=E_C_P_TEST123abc';

/* spec data, written out independently of content.js */
const SCENES = { 'paris-dusk': 'Paris dusk', 'rainy-tokyo': 'Rainy Night in Tokyo', 'arena-rock': 'Arena Rock', 'cliff-piano': 'Cliff Piano', 'road-trip': 'Road Trip in Camper Van', 'sunset-grass': 'Sunset grassland', 'street-rap': 'Street Rap', 'starry-village': 'Village Under Starry Sky' };
const GENRES = { pop: 'Pop & Vocals', hiphop: 'Hip-Hop & Rap', edm: 'EDM & Electronic', lofi: 'Lo-Fi & Chill Beats', jazz: 'Jazz & Soul', classical: 'Classical & Orchestral', cinematic: 'Cinematic & Soundtracks', unsure: 'Not sure yet' };

const results = [];
let currentLabel = '';
function check(name, pass, detail) {
  results.push({ label: currentLabel, name, pass: !!pass, detail: detail === undefined ? '' : String(detail) });
  console.log((pass ? '  PASS ' : '  FAIL ') + '[' + currentLabel + '] ' + name + (pass || detail === undefined ? '' : '  :: ' + String(detail).slice(0, 300)));
}

function startServer() {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      const u = new URL(req.url, 'http://x');
      let p = decodeURIComponent(u.pathname);
      if (p.endsWith('/')) p += 'index.html';
      const f = path.join(SITE, p);
      if (!f.startsWith(SITE)) { res.writeHead(403); return res.end(); }
      fs.readFile(f, (err, buf) => {
        if (err) { res.writeHead(404); return res.end('nf'); }
        res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-store' });
        res.end(buf);
      });
    }).listen(0, '127.0.0.1', () => resolve(srv));
  });
}

let ORIGIN = '';
async function newPage(browser, vp, opts = {}) {
  const page = await browser.newPage();
  await page.setViewport(vp);
  if (opts.ua) await page.setUserAgent(opts.ua);
  const log = { issues: [], requests: [], bytes: 0, blocked: [] };
  /* safety net: a stray click must never reach the live musegen.ai — every non-local request is aborted and recorded */
  if (opts.intercept !== false) {
    await page.setRequestInterception(true);
    page.on('request', req => {
      const u = req.url();
      if (u.startsWith(ORIGIN) || u.startsWith('data:') || u.startsWith('blob:')) return req.continue();
      log.blocked.push(u);
      return req.abort();
    });
  }
  page.on('console', m => { if (['error', 'warning'].includes(m.type())) log.issues.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', e => log.issues.push('pageerror: ' + e.message));
  page.on('requestfailed', r => log.issues.push('requestfailed: ' + r.url()));
  page.on('request', r => log.requests.push(r.url()));
  page.on('response', async r => {
    if (r.status() >= 400) log.issues.push('HTTP ' + r.status() + ': ' + r.url());
    try { log.bytes += (await r.buffer()).length; } catch (e) { /* redirects etc. */ }
  });
  page.log = log;
  return page;
}

/* Sample the layout width a few times right after a transition. Transient overflow (for example a translateX
   entry animation) makes mobile browsers rescale the layout viewport, which silently breaks taps. */
async function sampleOverflow(page, expectW) {
  const worst = { sw: 0, iw: expectW, bad: [] };
  for (let i = 0; i < 8; i++) {
    const o = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth }));
    worst.sw = Math.max(worst.sw, o.sw);
    if (o.iw !== expectW || o.sw > o.iw) worst.bad.push(o);
    await sleep(55);
  }
  return worst;
}
const stepKey = page => page.$eval('.step', el => (el.className.match(/step--(\w+)/) || [])[1]).catch(() => null);
const waitStep = (page, key, t = 4000) => page.waitForSelector('.step--' + key, { timeout: t });
async function pick(page, id) { await page.click('[data-id="' + id + '"]'); }
async function runQuiz(page, a) {
  await waitStep(page, 'scene');
  const order = [['scene', a.scene], ['genre', a.genre], ['star', a.star], ['song', a.song], ['fmt', a.fmt]];
  for (let i = 0; i < order.length; i++) {
    await waitStep(page, order[i][0]);
    await pick(page, order[i][1]);
  }
  await waitStep(page, 'compose');
  await waitStep(page, 'result', 5000);
}
const text = (page, sel) => page.$eval(sel, el => el.innerText.replace(/\s+/g, ' ').trim());

/* expected strings, re-derived from the spec */
function expectedBrief(a) {
  const sc = {
    'paris-dusk': 'Golden-hour Paris at dusk: lamplit bridges, café terraces and the skyline glowing behind the lead.',
    'rainy-tokyo': 'A rainy night in Tokyo: neon signs, wet streets full of reflections, umbrellas and slow, moody camera moves.',
    'arena-rock': 'A huge arena show: stage lights, haze, a roaring crowd and sweeping camera moves on every chorus.',
    'cliff-piano': 'A piano on a windswept seaside cliff at sunset, waves below, slow cinematic push-ins on the emotional lines.',
    'road-trip': 'A camper-van road trip: open highway, golden-hour light, windows down, quick cuts on the beat.',
    'sunset-grass': 'A wide grassland at sunset: warm light, drifting grass, golden close-ups and gentle, free-spirited motion.',
    'street-rap': 'Late-night street scenes: graffiti walls, streetlights, the crew around the lead, hard cuts on the snare.',
    'starry-village': 'A painterly village under a swirling starry sky: lantern-lit rooftops, soft brush-stroke motion, dreamy pacing.',
  }[a.scene];
  const ge = {
    pop: 'Bright, catchy pop energy — keep the lead’s face and expressions front and center.',
    hiphop: 'Hip-hop swagger — confident posture and rhythmic cuts that land on the beat.',
    edm: 'Electronic build-and-drop energy — let the visuals surge on the drops.',
    lofi: 'Lo-fi calm — soft light, slow pacing and cozy details.',
    jazz: 'Jazz and soul warmth — intimate, smoky and unhurried.',
    classical: 'Orchestral sweep — grand, elegant and slow-building.',
    cinematic: 'Cinematic score — epic scale, dramatic lighting and an emotional arc.',
    unsure: 'Let the pacing and mood follow the song.',
  }[a.genre];
  const st = a.star === 'me' ? 'One lead character based on my uploaded photo, looking the same in every shot.' : 'One AI-designed lead character who stays consistent across every shot.';
  const fm = a.fmt === '9x16' ? 'Vertical 9:16 framing for TikTok, Reels and Shorts.' : 'Widescreen 16:9 framing.';
  return [sc, ge, st, fm].join(' ');
}
function expectedDest(query, a, withPicks = true) {
  const parts = [];
  if (query) parts.push(query);
  if (withPicks) parts.push('pl=quiz', 'pl_scene=' + a.scene, 'pl_genre=' + a.genre, 'pl_star=' + a.star, 'pl_song=' + a.song, 'pl_fmt=' + a.fmt);
  return DEST + (parts.length ? '?' + parts.join('&') : '');
}

/* WCAG contrast */
function lum(hex) {
  const c = hex.replace('#', '').match(/../g).map(h => parseInt(h, 16) / 255).map(v => (v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)));
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}
const ratio = (a, b) => { const l1 = lum(a), l2 = lum(b); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };

async function main() {
  const srv = await startServer();
  const origin = 'http://127.0.0.1:' + srv.address().port;
  ORIGIN = origin;
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'mgpl-test-'));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: true, userDataDir: prof, args: ['--no-first-run', '--disable-extensions', '--lang=en-US'] });
  const mobile = { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true };
  const A1 = { scene: 'paris-dusk', genre: 'pop', star: 'me', song: 'file', fmt: '9x16' };

  try {
    /* ============ 1. first paint, hygiene, size ============ */
    currentLabel = 'mobile-390';
    let page = await newPage(browser, mobile);
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    check('title mentions MuseGen', /MuseGen/.test(await page.title()));
    check('step 1 is the scene question', (await stepKey(page)) === 'scene');
    const scenes = await page.$$eval('.opts [data-id]', els => els.map(e => ({ id: e.dataset.id, t: e.innerText.replace(/\s+/g, ' ').trim(), role: e.getAttribute('role'), on: e.getAttribute('aria-checked') })));
    check('8 scene options with the real template names', scenes.length === 8 && Object.keys(SCENES).every(id => scenes.some(s => s.id === id && s.t.startsWith(SCENES[id]))), JSON.stringify(scenes.map(s => s.t)));
    check('options are radios, none pre-selected', scenes.every(s => s.role === 'radio' && s.on === 'false'));
    check('counter shows 1/5', (await text(page, '#count')) === '1/5');
    check('progressbar aria-valuenow=1', (await page.$eval('#bar', e => e.getAttribute('aria-valuenow'))) === '1');
    check('back button is hidden on step 1', await page.$eval('#back', e => getComputedStyle(e).visibility === 'hidden'));
    const fontsOk = await page.evaluate(async () => { await document.fonts.ready; return [document.fonts.check('700 20px "Clash Display"'), document.fonts.check('400 16px Sora')]; });
    check('self-hosted fonts load (Clash Display, Sora)', fontsOk[0] && fontsOk[1], JSON.stringify(fontsOk));
    check('no third-party requests with analytics off', page.log.requests.every(u => u.startsWith(origin) || u.startsWith('data:')), page.log.requests.filter(u => !u.startsWith(origin)).join(' '));
    check('page weight under 400 KB', page.log.bytes < 400 * 1024, page.log.bytes + ' bytes');
    const dupIds = await page.evaluate(() => { const seen = {}, d = []; document.querySelectorAll('[id]').forEach(e => { if (seen[e.id]) d.push(e.id); seen[e.id] = 1; }); return d; });
    check('no duplicate DOM ids on step 1 (8 inline SVGs)', dupIds.length === 0, dupIds.join(','));
    check('exactly one h1', (await page.$$('h1')).length === 1);
    const ov0 = await sampleOverflow(page, 390);
    check('layout viewport stays 390px wide on first paint (no overflow)', ov0.bad.length === 0, JSON.stringify(ov0.bad.slice(0, 2)));

    /* ============ 2. mechanics ============ */
    await pick(page, 'paris-dusk');
    check('selecting marks the option', await page.$eval('[data-id="paris-dusk"]', e => e.getAttribute('aria-checked') === 'true'));
    await waitStep(page, 'genre');
    const ov1 = await sampleOverflow(page, 390);
    check('no transient horizontal overflow while the next step animates in', ov1.bad.length === 0, JSON.stringify(ov1.bad.slice(0, 2)));
    check('auto-advances to step 2', (await text(page, '#count')) === '2/5');
    check('h1 receives focus after a step change', await page.evaluate(() => document.activeElement && document.activeElement.tagName === 'H1'));
    const w2 = await page.$eval('#fill', e => parseFloat(e.style.width));
    check('progress grows (2/6 ≈ 33%)', w2 > 30 && w2 < 36, w2);
    check('back button visible on step 2', await page.$eval('#back', e => getComputedStyle(e).visibility === 'visible'));
    await page.click('#back');
    await waitStep(page, 'scene');
    check('in-app Back returns to step 1 with the pick kept', await page.$eval('[data-id="paris-dusk"]', e => e.getAttribute('aria-checked') === 'true'));
    await pick(page, 'rainy-tokyo');
    await waitStep(page, 'genre');
    await pick(page, 'edm');
    await waitStep(page, 'star');
    await page.goBack();
    await waitStep(page, 'genre');
    check('browser back (history) from step 3 goes to step 2', (await text(page, '#count')) === '2/5' && await page.$eval('[data-id="edm"]', e => e.getAttribute('aria-checked') === 'true'));
    await page.goForward();
    await waitStep(page, 'star');
    check('browser forward works', true);
    await page.close();

    /* double tap guard + full run */
    page = await newPage(browser, mobile);
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    await Promise.all([page.click('[data-id="arena-rock"]'), page.click('[data-id="cliff-piano"]').catch(() => { })]);
    await waitStep(page, 'genre');
    await sleep(700);
    check('two quick taps advance only one step', (await stepKey(page)) === 'genre', await stepKey(page));
    await page.close();

    /* ============ 3. full run: compose, result, brief, CTA ============ */
    page = await newPage(browser, mobile);
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    await waitStep(page, 'scene');
    for (const [k, v] of [['scene', A1.scene], ['genre', A1.genre], ['star', A1.star], ['song', A1.song], ['fmt', A1.fmt]]) { await waitStep(page, k); await pick(page, v); }
    await waitStep(page, 'compose');
    const recap = await page.$$eval('.recap li', els => els.map(e => e.innerText.replace(/\s+/g, ' ').trim()));
    check('compose beat recaps the 5 picks', recap.length === 5 && /Paris dusk/.test(recap[0]) && /Pop & Vocals/.test(recap[1]) && /Me/.test(recap[2]) && /I have a song file/.test(recap[3]) && /Vertical 9:16/.test(recap[4]), JSON.stringify(recap));
    await waitStep(page, 'result', 5000);
    const ov2 = await sampleOverflow(page, 390);
    check('no transient horizontal overflow while the result animates in', ov2.bad.length === 0, JSON.stringify(ov2.bad.slice(0, 2)));
    check('result headline names the scene', /Paris dusk/.test(await text(page, 'h1')));
    check('result counter 5/5 and bar full', (await text(page, '#count')) === '5/5' && (await page.$eval('#fill', e => e.style.width)) === '100%');
    const brief = await text(page, '#brief');
    check('brief text matches the spec composition', brief === expectedBrief(A1), brief);
    check('brief fits the 1000-char Description limit', brief.length > 150 && brief.length <= 1000, brief.length);
    const href = await page.$eval('#cta', e => e.getAttribute('href'));
    check('CTA = promo-slug destination + original query verbatim + pl picks', href === expectedDest(TT_QUERY, A1), href);
    check('ttclid forwarded exactly once', (href.match(/ttclid=/g) || []).length === 1);
    check('CTA opens in the same tab, rel=noopener', await page.$eval('#cta', e => !e.target && /noopener/.test(e.rel)));
    check('no songmaker link when the song is a file', (await page.$('#songmaker')) === null);
    const stepsTxt = await text(page, '.steps');
    check('steps tailored: file + me + 9:16', /Upload music/.test(stepsTxt) && /Image to Video/.test(stepsTxt) && /Upload photo/.test(stepsTxt) && /Paris dusk/.test(stepsTxt) && /9:16/.test(stepsTxt), stepsTxt);
    check('expectations mention 10–15 min, My MVs, free preview, refund, sign-in', (t => /10–15 minutes/.test(t) && /My MVs/.test(t) && /preview/.test(t) && /refunded/.test(t) && /sign in/.test(t))(await text(page, '.expect')));
    check('fine print: AI-generated, personal use, auto-renew', (t => /AI-generated/.test(t) && /personal use/.test(t) && /renew automatically/.test(t))(await text(page, '.fine')));

    /* copy button */
    await browser.defaultBrowserContext().overridePermissions(origin, ['clipboard-read', 'clipboard-write']).catch(() => { });
    await page.click('[data-act="copy"]');
    await sleep(300);
    check('Copy button confirms with "Copied ✓"', (await text(page, '[data-act="copy"]')) === 'Copied ✓', JSON.stringify({ btn: await text(page, '[data-act="copy"]'), blocked: page.log.blocked }));
    const clip = await page.evaluate(() => navigator.clipboard.readText().catch(e => 'ERR ' + e.message));
    check('clipboard holds the brief', clip === expectedBrief(A1), String(clip).slice(0, 120));

    check('main run never tried to leave the local origin', page.log.blocked.length === 0, page.log.blocked.join(' '));
    /* the sticky CTA must never cover the fine print or "Start over" once scrolled to the end */
    await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
    await sleep(250);
    const covered = await page.evaluate(() => {
      const probe = sel => { const el = document.querySelector(sel); const r = el.getBoundingClientRect(); const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return { inView: r.top >= 0 && r.bottom <= window.innerHeight, coveredByCta: !!(hit && hit.closest('.cta-bar')) }; };
      return { fine: probe('.fine'), again: probe('.again button'), legal: probe('.legal') };
    });
    check('scrolled to the end: fine print and Start over are visible, not under the CTA bar', covered.fine.inView && !covered.fine.coveredByCta && covered.again.inView && !covered.again.coveredByCta && covered.legal.inView, JSON.stringify(covered));
    await page.evaluate(() => window.scrollTo(0, 0));

    /* back from result, reload, start over */
    await page.click('#back');
    await waitStep(page, 'fmt');
    check('Back from result lands on question 5 with the pick kept', await page.$eval('[data-id="9x16"]', e => e.getAttribute('aria-checked') === 'true'));
    await page.goForward();
    await waitStep(page, 'result');
    await page.reload({ waitUntil: 'networkidle0' });
    await waitStep(page, 'result');
    check('reload on the result keeps the result', true);
    const hrefAfter = await page.$eval('#cta', e => e.getAttribute('href'));
    check('CTA identical after reload', hrefAfter === href);
    await page.click('[data-act="again"]');
    await waitStep(page, 'scene');
    check('Start over clears picks', await page.$$eval('.opts [data-id]', els => els.every(e => e.getAttribute('aria-checked') === 'false')));
    await page.close();

    /* new ad click (different query) in a fresh tab must not inherit the old answers */
    page = await newPage(browser, mobile);
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    await runQuiz(page, A1);
    await page.goto(origin + '/?utm_source=tiktok&ttclid=OTHER', { waitUntil: 'networkidle0' });
    check('different ad URL starts a fresh quiz', (await stepKey(page)) === 'scene' && (await text(page, '#count')) === '1/5');
    await page.close();

    /* ============ 3b. answers that vanish mid-flow must never crash the page ============ */
    page = await newPage(browser, mobile);
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    await runQuiz(page, A1);
    await page.click('[data-act="again"]');
    await waitStep(page, 'scene');
    await page.goBack();
    await waitStep(page, 'scene');
    check('Start over, then browser Back: lands on the first open question, no errors', (await text(page, '#count')) === '1/5' && page.log.issues.length === 0, page.log.issues.join(' | '));
    await page.close();

    page = await newPage(browser, mobile);
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    for (const [k, v] of [['scene', 'arena-rock'], ['genre', 'pop'], ['star', 'ai']]) { await waitStep(page, k); await pick(page, v); }
    await waitStep(page, 'song');
    await page.evaluate(() => sessionStorage.clear());
    await page.reload({ waitUntil: 'networkidle0' });
    check('storage cleared mid-quiz + reload: falls back to the first unanswered question', (await stepKey(page)) === 'scene', await stepKey(page));
    await runQuiz(page, A1);
    check('...and the quiz still completes normally afterwards', /Paris dusk/.test(await text(page, 'h1')) && page.log.issues.length === 0, page.log.issues.join(' | '));
    await page.close();

    /* ============ 4. branches ============ */
    page = await newPage(browser, mobile);
    const A2 = { scene: 'rainy-tokyo', genre: 'unsure', star: 'ai', song: 'official', fmt: '16x9' };
    await page.goto(origin + '/', { waitUntil: 'networkidle0' });
    await runQuiz(page, A2);
    const h2 = await page.$eval('#cta', e => e.getAttribute('href'));
    check('no-query visit: destination + only pl params (single "?")', h2 === expectedDest('', A2), h2);
    const t2 = await text(page, '.steps');
    check('steps tailored: official + AI lead + 16:9', /Official music/.test(t2) && /Music to Video/.test(t2) && !/Upload photo/.test(t2) && /16:9/.test(t2) && /Rainy Night in Tokyo/.test(t2), t2);
    check('songmaker link shown only for the official-track answer', (await page.$('#songmaker')) !== null && (await page.$eval('#songmaker', e => e.getAttribute('href'))) === 'https://www.musegen.ai/ai-song-maker');
    check('"Not sure yet" genre is not shown as a tag', !/Not sure yet/.test(await text(page, '.tags')));
    check('16:9 preview uses the wide frame', await page.$('.preview--16x9') !== null);
    check('brief matches spec (branch 2)', (await text(page, '#brief')) === expectedBrief(A2));
    await page.close();

    page = await newPage(browser, mobile);
    const A3 = { scene: 'starry-village', genre: 'cinematic', star: 'ai', song: 'suno', fmt: '9x16' };
    await page.goto(origin + '/?pl_scene=keepme&utm_source=tiktok', { waitUntil: 'networkidle0' });
    await runQuiz(page, A3);
    const h3 = await page.$eval('#cta', e => e.getAttribute('href'));
    check('existing pl_scene in the URL is not duplicated or overwritten', (h3.match(/pl_scene=/g) || []).length === 1 && /pl_scene=keepme/.test(h3), h3);
    check('steps tailored: suno', /Suno songs/.test(await text(page, '.steps')));
    await page.close();

    /* ============ 5. hostile query string ============ */
    page = await newPage(browser, mobile);
    await page.evaluateOnNewDocument(() => { window.__xss = 0; });
    const evil = 'x=%3Cimg%20src%3Dx%20onerror%3Dwindow.__xss%3D1%3E&utm_campaign=%22%3E%3Cscript%3Ewindow.__xss%3D2%3C%2Fscript%3E&a="onmouseover="window.__xss=3';
    await page.goto(origin + '/?' + evil, { waitUntil: 'networkidle0' });
    await runQuiz(page, A1);
    const evilHref = await page.$eval('#cta', e => e.getAttribute('href'));
    check('hostile query: nothing executes', (await page.evaluate(() => window.__xss)) === 0);
    check('hostile query: CTA still points at musegen.ai promo slug', evilHref.startsWith(DEST + '?') && (await page.$eval('#cta', e => e.hostname)) === 'www.musegen.ai', evilHref);
    check('hostile query: no injected elements', (await page.$$('main img, main script, #cta[onmouseover]')).length === 0);
    await page.close();

    /* ============ 6. keyboard, reduced motion, TikTok UA ============ */
    page = await newPage(browser, mobile);
    await page.goto(origin + '/', { waitUntil: 'networkidle0' });
    await page.focus('[data-id="paris-dusk"]');
    await page.keyboard.press('Enter');
    await waitStep(page, 'genre');
    check('keyboard: Enter on a focused option advances', true);
    await page.keyboard.press('Tab');
    check('keyboard: Tab moves focus into the options', await page.evaluate(() => !!document.activeElement && document.activeElement.hasAttribute('data-id') || document.activeElement.id === 'back'));
    await page.close();

    page = await newPage(browser, mobile);
    await page.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'reduce' }]);
    await page.goto(origin + '/', { waitUntil: 'networkidle0' });
    const t0 = Date.now();
    await runQuiz(page, A1);
    check('reduced motion: whole quiz completes, animations off', (await page.$eval('.step', e => getComputedStyle(e).animationName)) === 'none', Date.now() - t0);
    await page.close();

    page = await newPage(browser, mobile, { ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 musical_ly_37.1.0 JsSdk/2.0 NetType/WIFI Channel/App Store ByteLocale/en Region/US ByteFullLocale/en isDarkMode/1 WKWebView/1' });
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    await runQuiz(page, A1);
    check('TikTok in-app UA: full flow works', (await page.$eval('#cta', e => e.getAttribute('href'))) === expectedDest(TT_QUERY, A1));
    await page.close();

    /* ============ 7. consistency sweep over every answer combination (in-page) ============ */
    page = await newPage(browser, mobile);
    await page.goto(origin + '/', { waitUntil: 'networkidle0' });
    const sweep = await page.evaluate(() => {
      const C = window.MGPL_CONTENT, bad = [];
      let n = 0;
      C.scenes.forEach(sc => C.genres.forEach(ge => C.stars.forEach(st => C.songs.forEach(so => C.formats.forEach(fm => {
        const a = { scene: sc.id, genre: ge.id, star: st.id, song: so.id, fmt: fm.id };
        const b = C.buildBrief(a), steps = C.buildSteps(a);
        n++;
        if (!b || /undefined|null|\[object/.test(b) || b.length > 1000) bad.push(['brief', a]);
        if (steps.length !== 3 || steps.some(s => !s.h || !s.t || /undefined|null|\[object/.test(s.h + s.t))) bad.push(['steps', a]);
      })))));
      const art = C.scenes.map(s => window.MGPL_ART(s.id));
      const ids = [];
      art.forEach(svg => (svg.match(/ id="([^"]+)"/g) || []).forEach(m => ids.push(m)));
      return { n, bad: bad.slice(0, 3), artEmpty: art.filter(x => !x || x.length < 500).length, dupArtIds: ids.length - new Set(ids).size };
    });
    check('sweep: all ' + sweep.n + ' answer combinations build a valid brief and 3 steps', sweep.n === 8 * 8 * 2 * 3 * 2 && sweep.bad.length === 0, JSON.stringify(sweep.bad));
    check('sweep: every scene has artwork, SVG ids unique across scenes', sweep.artEmpty === 0 && sweep.dupArtIds === 0, JSON.stringify(sweep));
    await page.close();

    /* ============ 8. layout at several widths: no horizontal overflow, tap targets, contrast ============ */
    for (const [label, vp] of [['mobile-360', { ...mobile, width: 360, height: 740 }], ['mobile-320', { ...mobile, width: 320, height: 640 }], ['desktop-1280', { width: 1280, height: 800, deviceScaleFactor: 1 }]]) {
      currentLabel = label;
      page = await newPage(browser, vp);
      await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
      const overflow = async tag => {
        const o = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth }));
        check('no horizontal overflow @' + tag, o.sw <= o.iw, JSON.stringify(o));
      };
      const tapSmall = async tag => {
        const small = await page.$$eval('button, .btn', els => els.filter(e => e.offsetParent !== null && getComputedStyle(e).visibility !== 'hidden').map(e => { const r = e.getBoundingClientRect(); return { t: (e.innerText || e.getAttribute('aria-label') || '').trim().slice(0, 24), w: Math.round(r.width), h: Math.round(r.height) }; }).filter(r => r.w < 44 || r.h < 44));
        check('tap targets >= 44px @' + tag, small.length === 0, JSON.stringify(small));
      };
      const noName = async tag => {
        const bad = await page.$$eval('button, a[href]', els => els.filter(e => !(e.innerText || e.getAttribute('aria-label') || '').trim()).map(e => e.outerHTML.slice(0, 60)));
        check('every button/link has an accessible name @' + tag, bad.length === 0, bad.join(' | '));
      };
      await overflow('step1'); await tapSmall('step1'); await noName('step1');
      for (const [k, v] of [['scene', 'road-trip'], ['genre', 'classical'], ['star', 'ai'], ['song', 'official'], ['fmt', '16x9']]) {
        await waitStep(page, k); await pick(page, v);
        if (k !== 'fmt') { await sleep(450); await overflow(k); await tapSmall(k); }
      }
      await waitStep(page, 'result', 5000);
      await overflow('result'); await tapSmall('result'); await noName('result');
      const cta = await page.$eval('#cta', e => { const r = e.getBoundingClientRect(); return { top: r.top, bottom: r.bottom, vh: window.innerHeight }; });
      check('sticky CTA visible inside the viewport on the result @' + label, cta.bottom <= cta.vh + 1 && cta.top >= 0, JSON.stringify(cta));
      await page.close();
    }

    /* contrast (design tokens read from the live CSS) */
    currentLabel = 'contrast';
    page = await newPage(browser, mobile);
    await page.goto(origin + '/', { waitUntil: 'networkidle0' });
    const tok = await page.evaluate(() => { const cs = getComputedStyle(document.documentElement); const g = n => cs.getPropertyValue(n).trim(); return { base: g('--base'), raised: g('--raised'), brand: g('--brand'), brandOn: g('--brand-on'), text: g('--text'), label: g('--label'), secondary: g('--secondary'), fine: g('--fine') }; });
    const pairs = [['text/base', tok.text, tok.base], ['label/raised', tok.label, tok.raised], ['secondary/base', tok.secondary, tok.base], ['secondary/raised', tok.secondary, tok.raised], ['fine/base', tok.fine, tok.base], ['brand(kicker)/base', tok.brand, tok.base], ['brandOn/brand(CTA, step badges)', tok.brandOn, tok.brand], ['brandOn/lime(CTA start)', tok.brandOn, '#B0FF3C'], ['brandOn/mint(CTA end)', tok.brandOn, '#25F5B4']];
    for (const [n, fg, bg] of pairs) { const r = ratio(fg, bg); check('contrast ' + n + ' >= 4.5 (' + r.toFixed(2) + ')', r >= 4.5, fg + ' on ' + bg); }
    await page.close();

    /* ============ 9. analytics hook (config override, requests blocked + recorded) ============ */
    currentLabel = 'pixel-hook';
    page = await newPage(browser, mobile, { intercept: false });
    const hits = [];
    await page.setRequestInterception(true);
    page.on('request', req => {
      const u = req.url();
      if (u.endsWith('/assets/config.js')) {
        return req.respond({ status: 200, contentType: 'text/javascript', body: "window.MGPL={destination:'https://www.musegen.ai/mv-generation/rb00_1music',songMakerUrl:'https://www.musegen.ai/ai-song-maker',forwardQuery:true,appendPicks:false,tiktokPixel:'TESTPIXEL123',ga4:'G-TEST123'};" });
      }
      if (!u.startsWith(origin)) { hits.push(u); return req.respond({ status: 200, contentType: 'text/javascript', body: '' }); }
      return req.continue();
    });
    await page.goto(origin + '/?' + TT_QUERY, { waitUntil: 'networkidle0' });
    await pick(page, 'paris-dusk');
    await waitStep(page, 'genre');
    check('TikTok pixel script requested with the configured sdkid', hits.some(u => u.includes('analytics.tiktok.com') && u.includes('sdkid=TESTPIXEL123')), hits.join(' '));
    check('GA4 script requested with the configured id', hits.some(u => u.includes('googletagmanager.com/gtag/js') && u.includes('id=G-TEST123')), hits.join(' '));
    const q = await page.evaluate(() => (window.ttq || []).map(x => Array.isArray(x) ? x[0] + ':' + (x[1] && x[1].toString ? x[1].toString() : '') : String(x)).filter(Boolean));
    check('ttq queue has page, PL_Start, PL_Pick', q.some(x => x.startsWith('page')) && q.some(x => x === 'track:PL_Start') && q.some(x => x === 'track:PL_Pick'), JSON.stringify(q));
    const dl = await page.evaluate(() => (window.dataLayer || []).filter(x => x && x.event).map(x => x.event + ':' + JSON.stringify(x.pl)));
    check('dataLayer events carry only step/value (no personal data)', dl.some(x => x === 'PL_Pick:{"step":"scene","value":"paris-dusk"}'), JSON.stringify(dl));
    await runQuizContinue(page);
    const href4 = await page.$eval('#cta', e => e.getAttribute('href'));
    check('appendPicks:false forwards only the original query', href4 === DEST + '?' + TT_QUERY, href4);
    await page.close();
  } finally {
    await browser.close().catch(() => { });
    srv.close();
    try { fs.rmSync(prof, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }

  const fails = results.filter(r => !r.pass);
  console.log('\n' + results.length + ' checks, ' + (results.length - fails.length) + ' passed, ' + fails.length + ' failed');
  if (fails.length) { console.log('FAILED:'); fails.forEach(f => console.log('  [' + f.label + '] ' + f.name + ' :: ' + f.detail.slice(0, 300))); process.exit(1); }
}

/* continue the quiz from wherever it is (used after the pixel checks left it on step 2) */
async function runQuizContinue(page) {
  const order = [['genre', 'pop'], ['star', 'me'], ['song', 'file'], ['fmt', '9x16']];
  for (const [k, v] of order) { await waitStep(page, k); await pick(page, v); }
  await waitStep(page, 'result', 5000);
}

main().catch(e => { console.error('TEST HARNESS ERROR', e); process.exit(2); });
