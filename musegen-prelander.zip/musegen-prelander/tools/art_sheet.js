'use strict';
/* node art_sheet.js <outPng>
   Renders every scene illustration inside the result-page preview frame, 9:16 and 16:9, on one sheet. */
const http = require('http'); const fs = require('fs'); const os = require('os'); const path = require('path');
const puppeteer = require('C:/Users/Administrator/used-iphone-store-tools/node_modules/puppeteer-core');
const SITE = path.resolve(__dirname, '..', 'site');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.woff2': 'font/woff2' };
(async () => {
  const srv = http.createServer((req, res) => { const p = new URL(req.url, 'http://x').pathname; const f = path.join(SITE, p.endsWith('/') ? p + 'index.html' : p); fs.readFile(f, (e, b) => { if (e) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' }); res.end(b); }); }).listen(0, '127.0.0.1');
  await new Promise(r => srv.on('listening', r));
  const origin = 'http://127.0.0.1:' + srv.address().port;
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'art-'));
  const browser = await puppeteer.launch({ executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: true, userDataDir: prof, args: ['--no-first-run'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900, deviceScaleFactor: 1 });
  await page.goto(origin + '/', { waitUntil: 'networkidle0' });
  await page.evaluate(() => {
    const C = window.MGPL_CONTENT;
    document.body.innerHTML = '<style>body{background:#050A07;color:#fff;font:12px sans-serif;padding:16px}.g{display:grid;grid-template-columns:repeat(8,150px);gap:14px;align-items:start}.f{margin:0}.f .preview__frame{width:150px!important}.w{display:grid;grid-template-columns:repeat(4,300px);gap:14px;margin-top:16px}.w .preview__frame{width:300px!important}.shell{display:none}</style>';
    const mk = (id, ratio) => '<figure class="f preview preview--' + ratio + '" style="margin:0"><div class="preview__frame">' + window.MGPL_ART(id, ratio === '16x9') + '<span class="preview__tag">' + id + '</span></div></figure>';
    document.body.insertAdjacentHTML('beforeend', '<div class="g">' + C.scenes.map(s => mk(s.id, '9x16')).join('') + '</div>');
    // second set: remove ids by cloning markup with renamed ids so nothing collides
    const wide = C.scenes.map(s => mk(s.id, '16x9').replace(/id="([^"]+)"/g, 'id="w-$1"').replace(/url\(#([^)]+)\)/g, 'url(#w-$1)')).join('');
    document.body.insertAdjacentHTML('beforeend', '<div class="w">' + wide + '</div>');
  });
  await new Promise(r => setTimeout(r, 400));
  await page.screenshot({ path: process.argv[2], fullPage: true });
  await browser.close(); srv.close(); fs.rmSync(prof, { recursive: true, force: true });
  console.log('saved', process.argv[2]);
})().catch(e => { console.error('ERR', e); process.exit(1); });
