import sys, os
from PIL import Image

src = sys.argv[1]
out = sys.argv[2]
cols = int(sys.argv[3]) if len(sys.argv) > 3 else 5
tw = int(sys.argv[4]) if len(sys.argv) > 4 else 240
files = sorted(f for f in os.listdir(src) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')))
thumbs = []
for f in files:
    im = Image.open(os.path.join(src, f)).convert('RGB')
    print(f, im.size)
    r = tw / im.width
    th = int(im.height * r)
    thumbs.append(im.resize((tw, th)))
rows = (len(thumbs) + cols - 1) // cols
rh = max(t.height for t in thumbs)
sheet = Image.new('RGB', (cols * tw, rows * rh), (20, 20, 20))
for i, t in enumerate(thumbs):
    sheet.paste(t, ((i % cols) * tw, (i // cols) * rh))
sheet.save(out, quality=82)
print('sheet', sheet.size)
