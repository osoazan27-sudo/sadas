import re, sys, os, html, json

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
d = sys.argv[1]
lo = int(sys.argv[2])
hi = int(sys.argv[3])
files = sorted(f for f in os.listdir(d) if f.endswith('.html'))
for f in files:
    idx = int(f.split('_')[0])
    if idx < lo or idx > hi:
        continue
    h = open(os.path.join(d, f), encoding='utf-8').read()
    # the SSR body is inside the page; strip scripts/styles/head
    h2 = re.sub(r'<script.*?</script>', '', h, flags=re.S)
    h2 = re.sub(r'<style.*?</style>', '', h2, flags=re.S)
    b = h2[h2.find('<body'):] if '<body' in h2 else h2
    b = re.sub(r'<(img|source)[^>]*?(?:src|srcset)="([^"]+)"[^>]*>', lambda m: '\n[IMG ' + m.group(2).split('/')[-1][:30] + ']\n', b)
    b = re.sub(r'<video[^>]*>', '\n[VIDEO]\n', b)
    b = re.sub(r'<input([^>]*)>', lambda m: '\n[INPUT ' + ' '.join(re.findall(r'(type="[^"]*"|placeholder="[^"]*"|name="[^"]*")', m.group(1))) + ']\n', b)
    b = re.sub(r'<(button)\b[^>]*>', '\n[BTN] ', b)
    b = re.sub(r'<(div|section|p|h1|h2|h3|h4|li|label|span|a|br)\b[^>]*>', '\n', b)
    b = re.sub(r'</?[a-zA-Z][^>]*>', ' ', b)
    b = html.unescape(b)
    lines = [re.sub(r'\s+', ' ', l).strip() for l in b.split('\n')]
    lines = [l for l in lines if l and l not in ('powered by', 'Pixery')]
    print('=' * 8, f)
    print('\n'.join(lines)[:int(sys.argv[4]) if len(sys.argv) > 4 else 1800])
