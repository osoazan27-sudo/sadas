import re, sys, os, subprocess, json

entry = open(sys.argv[1], encoding='utf-8').read()
outdir = sys.argv[2]
m = re.search(r'screenOrder:\[(.*?)\]', entry)
ids = re.findall(r'"([^"]+)"', m.group(1))
print(len(ids), 'screens')
UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
os.makedirs(outdir, exist_ok=True)
for i, sid in enumerate(ids):
    url = 'https://survey.cloneai.ai/cloneai-star-in-the-music-video/en-US/' + sid + '.html'
    dst = os.path.join(outdir, '%02d_%s.html' % (i, sid))
    if os.path.exists(dst) and os.path.getsize(dst) > 1000:
        continue
    r = subprocess.run(['curl', '-sS', '-L', '-m', '30', '-A', UA, '-o', dst, '-w', '%{http_code}', url], capture_output=True, text=True)
    print(i, sid, r.stdout, os.path.getsize(dst) if os.path.exists(dst) else -1)
json.dump(ids, open(os.path.join(outdir, '_order.json'), 'w'))
