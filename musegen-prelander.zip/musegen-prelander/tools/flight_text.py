import re, sys, json

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
h = open(sys.argv[1], encoding='utf-8').read()
pat = sys.argv[2] if len(sys.argv) > 2 else None
chunks = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)</script>', h, re.S)
print('chunks', len(chunks))
allt = ''
for c in chunks:
    try:
        allt += json.loads('"' + c + '"')
    except Exception:
        allt += c.encode('utf-8').decode('unicode_escape', errors='ignore')
print('total flight chars', len(allt))
open(sys.argv[1] + '.flight.txt', 'w', encoding='utf-8').write(allt)
# pull "children":"text" strings
strs = re.findall(r'"children":"([^"]{12,})"', allt)
seen = set()
out = []
for s in strs:
    if s in seen:
        continue
    seen.add(s)
    out.append(s)
print(len(out), 'unique child strings')
for s in out:
    if pat and not re.search(pat, s, re.I):
        continue
    print('-', s[:260])
