import re, sys, html

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
src = sys.argv[1]
h = open(src, encoding='utf-8').read()
# drop scripts and styles
h2 = re.sub(r'<script.*?</script>', '', h, flags=re.S)
h2 = re.sub(r'<style.*?</style>', '', h2, flags=re.S)
body = h2[h2.find('<body'):] if '<body' in h2 else h2
# show structural skeleton with text
body = re.sub(r'<(img|source)[^>]*?(src|srcset)="([^"]+)"[^>]*>', lambda m: '[IMG ' + m.group(3)[:90] + ']', body)
body = re.sub(r'<(video)[^>]*?src="([^"]+)"[^>]*>', lambda m: '[VIDEO ' + m.group(2)[:90] + ']', body)
body = re.sub(r'<(button|a)\b[^>]*>', lambda m: '\n<' + m.group(1) + '>', body)
body = re.sub(r'<(div|section|p|h1|h2|h3|li|label|span|input|textarea|select|option)\b([^>]*)>', lambda m: '\n<' + m.group(1) + ' ' + (re.search(r'(data-[a-z-]+="[^"]*"|type="[^"]*"|placeholder="[^"]*"|name="[^"]*")', m.group(2)) or [''])[0] + '>', body)
body = re.sub(r'</?[a-zA-Z][^>]*>', ' ', body)
body = html.unescape(body)
lines = [re.sub(r'\s+', ' ', l).strip() for l in body.split('\n')]
lines = [l for l in lines if l]
print('\n'.join(lines)[:int(sys.argv[2]) if len(sys.argv) > 2 else 6000])
