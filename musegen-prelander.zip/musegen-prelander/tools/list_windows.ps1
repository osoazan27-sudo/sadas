# List every visible Chrome-family top-level window (title, pid, size, position). Read-only.
# usage: powershell -NoProfile -ExecutionPolicy Bypass -File tools\list_windows.ps1
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class WinList {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc p, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
}
"@
$rows = New-Object System.Collections.ArrayList
$cb = [WinList+EnumProc]{
  param($h, $l)
  if ([WinList]::IsWindowVisible($h)) {
    $t = New-Object System.Text.StringBuilder 512
    [void][WinList]::GetWindowText($h, $t, 512)
    $c = New-Object System.Text.StringBuilder 256
    [void][WinList]::GetClassName($h, $c, 256)
    if ($t.Length -gt 0 -and $c.ToString() -eq 'Chrome_WidgetWin_1') {
      $procId = [uint32]0
      [void][WinList]::GetWindowThreadProcessId($h, [ref]$procId)
      $r = New-Object WinList+RECT
      [void][WinList]::GetWindowRect($h, [ref]$r)
      [void]$rows.Add(('pid={0} size={1}x{2} at {3},{4} | {5}' -f $procId, ($r.R - $r.L), ($r.B - $r.T), $r.L, $r.T, $t.ToString()))
    }
  }
  return $true
}
[void][WinList]::EnumWindows($cb, [IntPtr]::Zero)
$rows | ForEach-Object { $_ }
