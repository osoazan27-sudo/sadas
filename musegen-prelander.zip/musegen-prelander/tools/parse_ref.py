import re, json, sys

src = sys.argv[1]
out = sys.argv[2]
h = open(src, encoding='utf-8').read()
scripts = re.findall(r'<script([^>]*)>(.*?)</script>', h, re.S)
body = scripts[1][1]
i = body.index('window.pix=')
txt = body[i + len('window.pix='):]
depth = 0
end = None
instr = False
esc = False
for k, ch in enumerate(txt):
    if instr:
        if esc:
            esc = False
        elif ch == chr(92):
            esc = True
        elif ch == '"':
            instr = False
    else:
        if ch == '"':
            instr = True
        elif ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                end = k + 1
                break
obj = json.loads(txt[:end])
print(list(obj.keys()))
for k, v in obj.items():
    s = json.dumps(v, ensure_ascii=False)
    print('==', k, len(s))
    print(s[:1200])
open(out, 'w', encoding='utf-8').write(json.dumps(obj, ensure_ascii=False, indent=1))
print('REST AFTER JSON:', txt[end:end + 800])
