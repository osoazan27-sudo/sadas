'use strict';
/* node peek_mv.js <outDir> [url]
   Read-only look at the live MuseGen MV page as a guest (mobile viewport, throw-away Chrome profile).
   Takes screenshots + dumps visible text of tabs/buttons. Clicks only UI tabs/pickers, never "Generate". */
const puppeteer = require('C:/Users/Administrator/used-iphone-store-tools/node_modules/puppeteer-core');
const fs = require('fs');
const os = require('os');
const path = require('path');

const outDir = process.argv[2];
const url = process.argv[3] || 'https://www.musegen.ai/mv-generation';
fs.mkdirSync(outDir, { recursive: true });
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'peek-'));
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: true, userDataDir: prof,
    args: ['--no-first-run', '--no-default-browser-check', '--disable-extensions', '--lang=en-US'],
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1');
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(2500);
    await page.screenshot({ path: path.join(outDir, '01_landing.png') });
    const info = await page.evaluate(() => {
      const t = el => (el.innerText || '').trim().replace(/\s+/g, ' ');
      return {
        title: document.title,
        buttons: [...document.querySelectorAll('button')].map(b => ({ t: t(b).slice(0, 60), dis: b.disabled, aria: b.getAttribute('aria-selected') })).filter(b => b.t).slice(0, 60),
        h: [...document.querySelectorAll('h1,h2,h3')].map(t).slice(0, 20),
      };
    });
    fs.writeFileSync(path.join(outDir, 'info.json'), JSON.stringify(info, null, 1));
    console.log(JSON.stringify(info, null, 1).slice(0, 4000));
    await page.screenshot({ path: path.join(outDir, '02_full.png'), fullPage: true });
  } finally {
    await browser.close();
    try { fs.rmSync(prof, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
})().catch(e => { console.error('ERR', e); process.exit(1); });
