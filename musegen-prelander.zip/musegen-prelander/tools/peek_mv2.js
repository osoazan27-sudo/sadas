'use strict';
/* node peek_mv2.js <outDir>
   Read-only walk through the live MV form UI as a guest: Music-to-Video tab, music picker, style-template chip,
   "More options". Never clicks Generate. */
const puppeteer = require('C:/Users/Administrator/used-iphone-store-tools/node_modules/puppeteer-core');
const fs = require('fs');
const os = require('os');
const path = require('path');

const outDir = process.argv[2];
fs.mkdirSync(outDir, { recursive: true });
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function clickByText(page, text, exact = true) {
  const ok = await page.evaluate((text, exact) => {
    const els = [...document.querySelectorAll('button,[role=button],a,div[role=tab]')];
    const el = els.find(e => {
      const t = (e.innerText || '').trim().replace(/\s+/g, ' ');
      return exact ? t === text : t.startsWith(text);
    });
    if (!el) return false;
    el.scrollIntoView({ block: 'center' });
    el.click();
    return true;
  }, text, exact);
  return ok;
}
async function visibleText(page, max = 2500) {
  return page.evaluate(m => (document.body.innerText || '').replace(/\n{2,}/g, '\n').slice(0, m), max);
}

(async () => {
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'peek-'));
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: true, userDataDir: prof,
    args: ['--no-first-run', '--no-default-browser-check', '--disable-extensions', '--lang=en-US'],
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1');
    await page.goto('https://www.musegen.ai/mv-generation', { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(2500);

    console.log('click Music to Video:', await clickByText(page, 'Music to Video'));
    await sleep(1500);
    await page.screenshot({ path: path.join(outDir, '10_music_tab.png') });
    console.log('--- music tab text:\n' + (await visibleText(page, 1800)));

    console.log('click Image to Video:', await clickByText(page, 'Image to Video'));
    await sleep(1000);
    console.log('click Choose music:', await clickByText(page, 'Choose music'));
    await sleep(2500);
    await page.screenshot({ path: path.join(outDir, '11_choose_music.png') });
    console.log('--- picker text:\n' + (await visibleText(page, 2500)));
    await page.keyboard.press('Escape');
    await sleep(800);

    console.log('click Style template:', await clickByText(page, 'Style template'));
    await sleep(2500);
    await page.screenshot({ path: path.join(outDir, '12_style_template.png') });
    console.log('--- style tpl text:\n' + (await visibleText(page, 2500)));
  } finally {
    await browser.close();
    try { fs.rmSync(prof, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
})().catch(e => { console.error('ERR', e); process.exit(1); });
