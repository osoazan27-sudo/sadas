'use strict';
/* node peek_mv3.js <outDir>
   Read-only: capture the JSON API responses the live MV form loads for templates / official music (guest),
   save them to <outDir>/api_*.json. Never clicks Generate. */
const puppeteer = require('C:/Users/Administrator/used-iphone-store-tools/node_modules/puppeteer-core');
const fs = require('fs');
const os = require('os');
const path = require('path');

const outDir = process.argv[2];
fs.mkdirSync(outDir, { recursive: true });
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function clickByText(page, text) {
  return page.evaluate(text => {
    const els = [...document.querySelectorAll('button,[role=button],a')];
    const el = els.find(e => (e.innerText || '').trim().replace(/\s+/g, ' ') === text);
    if (!el) return false;
    el.scrollIntoView({ block: 'center' });
    el.click();
    return true;
  }, text);
}

(async () => {
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'peek-'));
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: true, userDataDir: prof,
    args: ['--no-first-run', '--no-default-browser-check', '--disable-extensions', '--lang=en-US'],
  });
  const seen = [];
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1');
    page.on('response', async r => {
      const u = r.url();
      if (!/musegen\.ai\/api\//.test(u)) return;
      const ct = (r.headers()['content-type'] || '');
      if (!ct.includes('json')) return;
      try {
        const body = await r.text();
        const name = 'api_' + u.replace(/^https?:\/\/[^/]+\/api\//, '').replace(/[^A-Za-z0-9]+/g, '_').slice(0, 80) + '.json';
        fs.writeFileSync(path.join(outDir, name), body);
        seen.push([r.status(), u, body.length]);
      } catch (e) { /* ignore */ }
    });
    await page.goto('https://www.musegen.ai/mv-generation', { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(2000);
    console.log('Choose music:', await clickByText(page, 'Choose music'));
    await sleep(2500);
    await page.keyboard.press('Escape');
    await sleep(600);
    console.log('Style template:', await clickByText(page, 'Style template'));
    await sleep(3500);
    // scroll the panel to trigger lazy loading
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await sleep(1500);
    // template names + categories from DOM
    const dom = await page.evaluate(() => {
      const out = [];
      document.querySelectorAll('button,div').forEach(el => {
        const t = (el.innerText || '').trim();
        if (/\nView$/.test(t) && t.length < 80) out.push(t.replace(/\n/g, ' | '));
      });
      return [...new Set(out)];
    });
    console.log('DOM template cards:', JSON.stringify(dom, null, 1));
    const media = await page.evaluate(() => ({
      imgs: [...document.querySelectorAll('img')].map(i => i.currentSrc || i.src).filter(Boolean).slice(0, 40),
      videos: [...document.querySelectorAll('video')].map(v => v.currentSrc || v.src).filter(Boolean).slice(0, 20),
    }));
    console.log('MEDIA', JSON.stringify(media, null, 1));
  } finally {
    await browser.close();
    try { fs.rmSync(prof, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
  console.log('API responses captured:'); seen.forEach(s => console.log(' ', s.join(' ')));
})().catch(e => { console.error('ERR', e); process.exit(1); });
