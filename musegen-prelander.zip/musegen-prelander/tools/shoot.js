'use strict';
/* node shoot.js <baseUrl> <outDir> [w=390] [h=844]
   Walks the quiz once (scene=paris-dusk ... ) and saves a screenshot of every screen for eyeballing.
   Throw-away Chrome profile; never touches open browser windows. */
const puppeteer = require('C:/Users/Administrator/used-iphone-store-tools/node_modules/puppeteer-core');
const fs = require('fs');
const os = require('os');
const path = require('path');

const [base, outDir, W = '390', H = '844', pick = ''] = process.argv.slice(2);
fs.mkdirSync(outDir, { recursive: true });
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const query = '?utm_source=tiktok&utm_id=1879111239386114&utm_campaign=MuseGen%20-%20TT%20-%20US%20-%20Prelander%20Test&utm_medium=paid&ttclid=E_C_P_TEST123';
const picks = (pick || 'paris-dusk,pop,me,file,9x16').split(',');

(async () => {
  const prof = fs.mkdtempSync(path.join(os.tmpdir(), 'shoot-'));
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: true, userDataDir: prof, args: ['--no-first-run', '--disable-extensions', '--lang=en-US'] });
  try {
    const page = await browser.newPage();
    const mobile = Number(W) < 700;
    await page.setViewport({ width: Number(W), height: Number(H), deviceScaleFactor: mobile ? 2 : 1, isMobile: mobile, hasTouch: mobile });
    const issues = [];
    page.on('console', m => { if (['error', 'warning'].includes(m.type())) issues.push(m.type() + ': ' + m.text()); });
    page.on('pageerror', e => issues.push('pageerror: ' + e.message));
    page.on('requestfailed', r => issues.push('requestfailed: ' + r.url()));
    await page.goto(base + '/' + query, { waitUntil: 'networkidle0' });
    await sleep(700);
    let n = 1;
    for (const id of picks) {
      await page.screenshot({ path: path.join(outDir, String(n).padStart(2, '0') + '_step.png') });
      if (n === 1) await page.screenshot({ path: path.join(outDir, '01_step_full.png'), fullPage: true });
      await page.click('[data-id="' + id + '"]');
      await sleep(900);
      n++;
    }
    await sleep(500);
    await page.screenshot({ path: path.join(outDir, String(n).padStart(2, '0') + '_compose.png') });
    await sleep(1700);
    await page.screenshot({ path: path.join(outDir, String(n + 1).padStart(2, '0') + '_result_top.png') });
    await page.screenshot({ path: path.join(outDir, String(n + 2).padStart(2, '0') + '_result_full.png'), fullPage: true });
    console.log('issues:', issues.length ? '\n' + issues.join('\n') : 'none');
  } finally {
    await browser.close();
    try { fs.rmSync(prof, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
})().catch(e => { console.error('ERR', e); process.exit(1); });
